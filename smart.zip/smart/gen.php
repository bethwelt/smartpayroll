<?php 

error_reporting(E_NOTICE);
?>
<?php  


	function convert_to_csv($input_array, $output_file_name, $delimiter)
{
	/** open raw memory as file, no need for temp files, be careful not to run out of memory thought */
	$f = fopen('php://memory', 'w');
	/** loop through array  */
	foreach ($input_array as $line) {
		/** default php csv handler **/
		fputcsv($f, $line, $delimiter);
	}
	/** rewrind the "file" with the csv lines **/
	fseek($f, 0);
	/** modify header to be downloadable csv file **/
	header('Content-Type: application/csv');
	header('Content-Disposition: attachement; filename="' . $output_file_name . '";');
	/** Send file to browser for download */
	echo stream_get_contents($f);
}
/** Array to convert to csv */
for($a=0; $a<=$pno;$a++)
{
	
	
	
	
	
	 $codes =randStrGen($digits); 
	$hash = $prefix."-".randStrGen1($digits);
	$psno = $prefix.gen2($digits);
	
$array_to_csv = Array(Array($codes,$psno,$hash,$uid));

convert_to_csv($array_to_csv, 'product_detail.csv', ',');
}



?> 

<?php


$connect = mysqli_connect("localhost", "root", "", "morigorg_morig15")
            or die("Cannot connect");
 
	$query = "INSERT INTO pcontents(prefix,uid,contents,name,date,datex,kra,ad,company)VALUES('$prefix','$uid','$contents','$name','$date','$datex','$kra','$ad','$company')";
    $result = mysqli_query($connect, $query)
            or die("PACUID CODE ALREADY PLEASE CHECK AND TRY AGAIN!!");	
?>
<?php
$connect = mysqli_connect("localhost", "root", "", "morigorg_morig15")
            or die("Cannot connect");
    $query = "INSERT INTO report (name,prefix,company,pno,username,kra,uid,type)VALUES ('$name ','$prefix','$company','$pno','$username','$kra','$uid','$type')";  
    $result = mysqli_query($connect, $query)
            or die("Error in inserting");		

?>
