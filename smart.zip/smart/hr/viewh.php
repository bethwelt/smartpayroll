
<?php
session_start();
if (!isset($_SESSION['username'])) 
{
die(header('Location: ../index.php'));
}

include('connection.php');
?>

<?php

$id =$_REQUEST['id'];

$result = mysql_query("SELECT * FROM holiday WHERE id= '$id'");
$test = mysql_fetch_array($result);
if (!$result) 
		{
		die("Error: Data not found..");
		}
				$da=$test['date'] ;
				$na= $test['name'] ;					
				$de=$test['desc'] ;
				//$CopyrightYear=$test['CopyrightYear'] ;

if(isset($_POST['save']))
{	
	$na_save = $_POST['name'];
	$da_save = $_POST['date'];
	$de_save = $_POST['desc'];
	//$copy_save = $_POST['copy'];

	mysql_query("UPDATE holiday SET name ='$na_save', date ='$da_save',
		 desc='$de_save' WHERE id= '$id'")
				or die(mysql_error()); 
	echo "Holiday updated!";
	
	header("Location: holis.php");			
}
//mysql_close($conn);
?>

<form method="post">
<table border='1' width='60%'>
	<tr>
		<td>Name:</td>
		<td><input type="text" name="name" value="<?php echo $na ?>"/></td>
	</tr>
	<tr>
		<td>Date</td>
		<td><input type="text" name="date" value="<?php echo $da ?>"/></td>
	</tr>
	<tr>
		<td>Description</td>
		<td><input type="text" name="desc" value="<?php echo $de ?>"/></td>
	</tr>
	
	<tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="save" value="save" /></td>
	</tr>
</table>
