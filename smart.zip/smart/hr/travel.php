<?php
session_start();
if (!isset($_SESSION['username'])) 
{
die(header('Location: ../index.php'));
}

?>



<?php
$conn = mysql_connect("localhost","root","");
mysql_select_db("newsalary",$conn);
$result = mysql_query("SELECT * FROM register_staff ");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Assign</title>
<link rel="stylesheet" href="../css/style.css" type="text/css" />
<link rel="stylesheet" href="style.css" type="text/css" />

<script type="text/javascript">
 	function proceed() 
	{
	  return confirm('update Payroll');
 	}
 </script>

</head>

<body>
  
<?php include("header.php");?>

<form name="frmUser1" method="post" action="">
<div style="width:auto;">
<table border="0" class="tblListForm">
<tr class="listheader">


<th>STAFF ID</th>

<th>FULL NAME&nbsp;</th>
<th>ID NO&nbsp;</th>
<th>EMPLOYEE PIN</th>
<th>EMPLOYER PIN</th>
<th>DEPARTMENT</th>
<th>POSITION;</th>


<th>BRANCH</th>

<th>BASIC SALARY</th>
<th>BANK NAME</th>
<th>ACCOUNT NO</th>

<th>ASSIGN TRAVEL</th>






</tr>
<?php
$i=0;
while($row = mysql_fetch_array($result)) {
if($i%2==0)
$classname="evenRow";
else
$classname="oddRow";
?>
<tr class="<?php if(isset($classname)) echo $classname;?>">
<td><?php echo $row["staff_id"]; ?></td>
<?php

  echo "<td>" .$row['fname'] . "</td>";
  echo "<td>" .$row['idno'] . "</td>";
  echo "<td>" .$row['emp_pin'] . "</td>";
   echo "<td>" .$row['empl_pin'] . "</td>";
  echo "<td>" .$row['department'] . "</td>";
  echo "<td>" .$row['position'] . "</td>";
   echo "<td>" .$row['branch'] . "</td>";
  echo "<td>" .$row['basic'] . "</td>";
  echo "<td>" .$row['bank'] . "</td>";
  echo "<td>" .$row['accno'] . "</td>";
  echo "<td><a rel='facebox' href='travel/assign.php?staff_id=".$row['staff_id']."&fname=".$row['fname']."' id='add'>Assign</a>";
 
  ?>
  
</tr>
<?php
$i++;
}
?>



  

      
   

<tr class="listheader">
<td colspan="50"></td>
</tr>
</table>




</div>
</div>
</body></html>