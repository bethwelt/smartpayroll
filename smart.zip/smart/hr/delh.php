<?php
  include("connection.php");  

	$id =$_REQUEST['id'];
	
	
	// sending query
	mysql_query("DELETE FROM holiday WHERE id = '$id'")
	or die(mysql_error());  	
	
	header("Location: holis.php");
?>