 <?php 
 include('../connection.php');
 $staff_id=$_GET['staff_id'];
 $result1 = mysql_query("SELECT * FROM LEAVES WHERE staff_id='$staff_id'");

$row1= mysql_fetch_array($result1);
$lo=$row1['name']; 
        $m=$row1['from'];
        $o=$row1['to'];
        $ad=$row1['reason'];


 $result1 = mysql_query("SELECT * FROM leavelist ");

$row2= mysql_fetch_array($result1);
$na=$row2['name']; 
     
   

?>
<form method="post" action='leave/save.php'>
<table>
<tr>
		<td>Select Leave:</td>
		<td><select name="name" >
		
		
		<option>
		<?php echo $na; ?>
		</option>
		
		</select></td>
	</tr>
	<tr>
		<td>From:</td>
		<td><input type="text" name="from" value="<?php echo $m; ?>"/></td>
	</tr>
	<tr>
		<td>To</td>
		<td><input type="text" name="to" value="<?php echo $o; ?>"/></td>
	</tr>
	<tr>
		<td>Reason:</td>
		<td><input type="text" name="advance" value="<?php echo $ad; ?>"/></td>
	</tr>
	
	
		<td> Names </td>
		<td><input type="text" name="fname" value="<?php echo $_GET['fname'];?>" readonly/></td>
	</tr>
	<tr>
		<td>Staff Id</td>
		<td><input type="text" name="staff_id" value="<?php echo $_GET['staff_id'];?>" readonly/></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="submit" value="add" /></td>
	</tr>
</table>

</form>
<table border="1">
	
			
</table>

