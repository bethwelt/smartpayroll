<?php
if (isset($_POST['submit']))
	{	   
	include '../connection.php';
	$date=date('M,Y');
	
			 		$staff_id=$_POST['staff_id'] ;
					$fr=$_POST['from'] ;
					$na=$_POST['name'] ;
					$to=$_POST['to'] ;
//$re=$_POST['reason'] ;
					$fname=$_POST['fname'] ;
					$status ='active';

					$insert = ("UPDATE leaves SET fname='$fname',from='$fr',name='$na',to='$to',name='$na',status='$status' where staff_id='$staff_id'");
$qry = mysql_query($insert) or die(mysql_error());
if($insert)
	{
		echo "success";
		echo "<br />";
		//echo "<a href=index.php> Home </a>";
						header("location:../leave.php");

	}
else
	{
		echo "failed";
	}
										
												
				      }
?>