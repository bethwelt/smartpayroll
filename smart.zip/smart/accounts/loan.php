

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add loans</title>
<link rel="stylesheet" href="../css/style.css" type="text/css" />
<script src="../../SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<link href="../../SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
  function proceed() 
  {
    return confirm('Compute Payroll');
  }
 </script>
</head>

<body>
<div id="outerwrapper">
<div id="header"></div>
<?php include('header.php');?>
<div id="body">
  <table border="1">
    <tr>
      <td>
<p><form action="search.php" method="GET">
    <input type="text" name="emp_pin" />
    <input type="submit" value="Search" />
</form></p></td>
</tr>
</table>
<table border="1">
  <?php
session_start();
if (!isset($_SESSION['username'])) 
{
die(header('Location: ../index.php'));
}
error_reporting(E_NOTICE);
//database connection
include('connection.php');
include('../sanitise.php');
  //$staff_id= sanitise($_GET['staff_id']);
   $emp_pin = $_GET['emp_pin'];
$qry =("SELECT * FROM register_staff WHERE emp_pin= '$emp_pin'");
$update = mysql_query($qry) or die(mysql_error());
if($row_update = mysql_fetch_assoc($update))

$totalRows_update = mysql_num_rows($update);
else{echo "No results";}
?>


</table>
<form method="post" name="form1" action="lprocess.php">


   <table  border="1">

    <table border="1">
  <tr>
    <?php $date=date('M,Y');?>
    <td><strong>STAFF NO:</strong></td>
    <td><?php echo $row_update['staff_id']; ?></td>
    <td><strong>NAME:</strong></td>
    <td width="181"><?php echo $row_update['fname']; ?></td>
    <td><strong>EMPLOYEES PIN:</strong></td>
    <td><?php echo $row_update['emp_pin']; ?></td>

  </tr>
   <tr>
   
    <td><strong>EMPLOYERS PIN:</strong></td>
    <td width="181"><?php echo $row_update['empl_pin']; ?></td>
    
      <td width="87"><strong>DEPARTMENT:</strong></td>
    <td width="368"><?php echo $row_update['department']; ?></td>
    <td><strong>PAYSLIP PERIOD:</strong></td>
    <td><?php echo $date; ?></td>
  </tr>
  <tr>
  
    <td width="83"><strong>POSITION:</strong></td>
    <td><?php echo $row_update['position']; ?></td>

    <td><strong>YEARS WORKED:</strong></td>
    <td><?php echo $row_update['years']; ?></td>
    
  </tr></table>
  <HR>
    <table border="1">
    
    <tr>
      <td nowrap align="right">Basic Salary</td>
      <td><input type="text" name="basic" value="<?php echo $row_update['basic']; ?>" size="32" readonly></td>
    </tr>
   <tr>
      <td nowrap align="right">LOANS</td>
      <td><input type="text" name="loans" value="" size="32" ></td>
    </tr>
   
     </table>
    <tr>
      <td nowrap align="right">&nbsp;</td>
      <td><input type="submit" name="submit" value="Add loans"></td>
    </tr>
  </table>
</form>
</div>
</div>

</body>
</html>