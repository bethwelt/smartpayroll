
			<?php
			//include("connection.php");
			//$basic=100000;
				
			$result=mysql_query("SELECT lower,higher,amount FROM config_nhif where $basic  BETWEEN lower AND higher;");
			
			while($test = mysql_fetch_array($result))
			{
				
		
				
				$lw=$test['lower'];
				$hi=$test['higher'];
				$am=$test['amount'];
			
				$nhif=$am;	
				
			}


//echo $nhif;
?>