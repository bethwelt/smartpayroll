<?php
session_start();
if (!isset($_SESSION['username'])) 
{
die(header('Location: ../index.php'));
}

include('connection.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Back up</title>
<link rel="stylesheet" href="../css/style.css" type="text/css" />
<link rel="stylesheet" href="../css/menu.css" type="text/css" />

<script type="text/javascript">
    function proceed() 
    {
      return confirm('Compute Payroll');
    }
 </script>

</head>

<body><div id="outerwrapper">
	
    <div id="header"></div>
<?php include("header.php");?><div id="body">
<center>
<form method="post">
<table border='1' width='60%'>

	<tr>
		<td>FROM:</td>
		<td><input type="number" name="lower" /></td>
	</tr>
	<tr>
		<td>TO:</td>
		<td><input type="number" name="higher" /></td>
	</tr>
	<tr>
		<td>AMOUNT CHARGED:</td>
		<td><input type="number" name="amount" /></td>
	</tr>
	
	<tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="submit" value="add" /></td>
	</tr>
</table>
<?php
if (isset($_POST['submit']))
	{	   
	
	
			 		$lower=$_POST['lower'] ;
					$higher= $_POST['higher'] ;					
					$amount=$_POST['amount'] ;
					//$copy=$_POST['copy'] ;
												
		 mysql_query("INSERT INTO `config_nhif`(lower,higher,amount) 
		 VALUES ('$lower','$higher','$amount')"); 
				
				
	        }
?>

</form>
<table border="1" width='60%'>
	
			<?php
			//include("db.php");
			
				
			$result=mysql_query("SELECT * FROM config_nhif");
			
			while($test = mysql_fetch_array($result))
			{
				$id = $test['id'];	
				echo "<tr align='center'>";	
				echo"<td><font color='black'>" .$test['id']."</font></td>";
				echo"<td><font color='black'>" .$test['lower']."</font></td>";
				echo"<td><font color='black'>". $test['higher']. "</font></td>";
				echo"<td><font color='black'>". $test['amount']. "</font></td>";
				//echo"<td><font color='black'>". $test['CopyrightYear']. "</font></td>";	
				echo"<td> <a rel='facebox' href='view.php?id=$id' id='add'>Edit</a>";
				echo"<td> <a href ='del.php?id=$id'><center>Delete</center></a>";
									
				echo "</tr>";
			}
			//mysql_close($conn);
			?>
</table>
</center>
</div>

<br>
<br>
<br>
</body>
</html>
