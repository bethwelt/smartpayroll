<?php
session_start();
if (!isset($_SESSION['username'])) 
{
die(header('Location: ../index.php'));
}

//database connection
include('connection.php');
include('../sanitise.php');
$id= sanitise($_GET['id']);
$qry =("SELECT * FROM register_staff WHERE id = '$id'");
$update = mysql_query($qry) or die(mysql_error());
$row_update = mysql_fetch_assoc($update);
$totalRows_update = mysql_num_rows($update);
?>

<script type="text/javascript">
 	function proceed() 
	{
	  return confirm('Compute Payroll');
 	}
 </script>
</head>




<form method="post" name="form1" action="salprocessor2.php">
  <table align="center">
    <tr>
      <td nowrap align="right">Staff ID:</td>
      <td><input name="staff_id" type="text" value="<?php echo $row_update['staff_id']; ?>" size="32" readonly="readonly">
        <input name="id" type="HIDDEN" value="<?php echo $row_update['id']; ?>" size="32" readonly="readonly"></td>
    </tr>
     <tr>
      <td nowrap align="right">Eployee Pin:</td>
      <td><input name="emp_pin" type="text" id="emp_pin" value="<?php echo $row_update['emp_pin']; ?>" size="32" readonly></td>
    </tr>
     <tr>
      <td nowrap align="right">Eployer Pin:</td>
      <td><input name="empl_pin" type="text" id="empl_pin" value="<?php echo $row_update['empl_pin']; ?>" size="32" readonly></td>
    </tr>
   
    <tr>
      <td nowrap align="right">Full Name</td>
      <td><input name="fname" type="text" id="fname" value="<?php echo $row_update['fname']; ?>" size="32"></td>
    </tr>
    <tr>
      <td nowrap align="right">Department</td>
      <td><input name="department" type="text" value="<?php echo $row_update['department']; ?>" size="32" readonly="readonly"></td>
    </tr>
 	<tr>
      <td nowrap align="right">	Position</td>
      <td><input name="position" type="text" value="<?php echo $row_update['position']; ?>" size="32" readonly="readonly"></td>
    </tr>
    <tr>
      <td nowrap align="right">Years Spent:</td>
      <td><input name="years" type="text" value="<?php echo $row_update['years']; ?>" size="32" readonly="readonly"></td>
    </tr>
    <tr>
      <td nowrap align="right">Grade Level:</td>
      <td><input name="grade" type="text" value="<?php echo $row_update['grade']; ?>" size="32" readonly="readonly"></td>
    </tr>
    <tr>
      <td nowrap align="right">Basic Salary</td>
      <td><input type="text" name="basic" value="<?php echo $row_update['basic']; ?>" size="32"></td>
    </tr>

      
      <td><input type="hidden" name="meal" value="" size="32"></td>
    
  
     
    <tr>
      <td nowrap align="right">&nbsp;</td>
      <td><input type="submit" name="submit" value="Calculate Payroll" onclick="proceed()"></td>
    </tr>
  </table>
</form>

