



<?php

function get_paginate_links($total_rows, $entries_per_page, $current_page, $link_to)
{
	$total_page = ceil($total_rows / $entries_per_page);
	$str_page	= (strpos($link_to, "?") === false) ? "?page" : "&amp;page";
	
	if ($current_page == 1) {
		$paginate_links = "<div>&laquo; Prev</div>";
	} else {
		$paginate_links = "<div><a href=\"$link_to$str_page=" . ($current_page - 1) . 
							"\">&laquo; Prev</a></div>";
	}
	
	for ($i = 1; $i <= $total_page; $i++) {
		if ($i == $current_page) {
			$paginate_links .= "<div class=\"current-page\">$i</div>";
		} else {
			$paginate_links .= "<div><a href=\"$link_to$str_page=$i\">$i</a></div>";
		}
	}
	
	if ($current_page == $total_page) {
		$paginate_links .= "<div>Next &raquo;</div>";
	} else {
		$paginate_links .= "<div><a href=\"$link_to$str_page=" . ($current_page + 1) . 
							"\">Next &raquo;</a></div>";
	}
	
	print $paginate_links;
}
?>