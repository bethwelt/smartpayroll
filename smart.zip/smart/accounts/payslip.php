<?php
session_start();
if (!isset($_SESSION['username'])) 
{
die(header('Location: ../index.php'));
}

?>
<?php
//database connection
include('connection.php');
include('../sanitise.php');
$staff_id = sanitise($_GET['staff_id']);
$salary_id = sanitise($_GET['salary_id']);
$qry =("SELECT * FROM salary WHERE staff_id = '$staff_id' AND salary_id = '$salary_id'");
$update = mysql_query($qry) or die(mysql_error());
$row_update = mysql_fetch_assoc($update);
$totalRows_update = mysql_num_rows($update);
?>

  <script language="javascript">
function caaictpms()
{ 
  var disp_setting="toolbar=yes,location=no,directories=no,menubar=no,"; 
      disp_setting+="scrollbars=yes"; 
  var content_vlue = document.getElementById("print_content").innerHTML; 
  
  var docprint=window.open("","",disp_setting); 
   docprint.document.open(); 
   docprint.document.write('<html>'); 
      docprint.document.write('');
   docprint.document.write('</head><body onLoad="self.print()" style="width:400px; font-size:10px; margin-left:40px; -cell-padding:none;font: 12px/17px arial, sans-serif;color: rgb(50, 50, 50);">');
             
   docprint.document.write(content_vlue);          
   docprint.document.write('</body></html>'); 
   docprint.document.close(); 
   docprint.focus(); 
}
</script>
<div  id="print_content">
                          <center> <p class="pprint"> <a href="javascript:caaictpms()" >print</a></p></center>

<table width="80%" border="1">
  <tr>
 <td colspan="1" align="center"><span class="text"><small>EXAMPLE COMPANY LIMITED</small></span><br />
      <span class="text"><small>P.O BOX 123</small></span><br />
       <span class="text"><small>EXAMPLE TOWN.</small></span><br />
      info@example.com<br />    
    
      <hr>
   <table>
  <tr>
    <?php $date=date('M,Y');?>
    <td><strong>STAFF NO:</strong></td>
    <td><?php echo $row_update['staff_id']; ?></td>
    <td><strong>NAME:</strong></td>
    <td width="181"><?php echo $row_update['fname']; ?></td>
    <td><strong>EMPLOYEES PIN:</strong></td>
    <td><?php echo $row_update['emp_pin']; ?></td>

  </tr>
   <tr>
   
    <td><strong>EMPLOYERS PIN:</strong></td>
    <td width="81"><?php echo $row_update['empl_pin']; ?></td>
    
      <td width="87"><strong>DEPARTMENT:</strong></td>
    <td width="168"><?php echo $row_update['department']; ?></td>
    <td width="87"><strong>PAYSLIP PERIOD:</strong></td>
    <td><?php echo $row_update['period']; ?></td>
  </tr>
</table>

<table width="60%" border="">
  <tr>
    <td width="478" height="180" valign="top"><table width="440" border="">
      <tr>
        <td width="153" valign="top"><table width="105" border="">
           <tr>
        <strong> Salary/Allowances </strong>
        
          <tr>
      <tr>
        <td width="100"><strong>Basic Salary</strong></td>
        <td width="100"><?php echo $row_update['basic']; ?></td>
      </tr>
      <tr>
        <td><strong>Housing All.</strong></td>
        <td><?php echo $row_update['housing']; ?></td>
      </tr>
      <tr>
        <td><strong>Meal All.</strong></td>
        <td><?php echo $row_update['meal']; ?></td>
      </tr>
      <tr>
        <td><strong>Transport All.</strong></td>
        <td><?php echo $row_update['transport']; ?></td>
      </tr>
      <tr>
        <td><strong>Entertainment All.</strong></td>
        <td><?php echo $row_update['entertainment']; ?></td>
      </tr>
      <tr>
        <td><strong>Long Services</strong></td>
        <td><?php echo $row_update['long_service']; ?></td>
      </tr>
      


     
    </table>
        <td width="192" valign="top"><table width="244" border="">
          <tr>
        <strong> Tax Deductions </strong>
        
          <tr>
        <td><strong>Total income</strong></td>
        <td><?php echo $row_update['totalincome']; ?></td>
      </tr>
      <tr>
      <tr>
        <td><strong>Pension(NSSF)</strong></td>
        <td><?php echo $row_update['pension']; ?></td>
      </tr>


      <tr>

        <td>Total Taxable Income</td>
        <td><center><strong>&nbsp;&nbsp;&nbsp;<?php echo $row_update['taxincome']; ?></strong></center></td>
      </tr>

<tr>
        <td><strong>PAYE/Gross Tax</strong></td>
        <td><?php echo $row_update['payee']; ?></td>
      </tr>
       <tr>
        <td><strong>Personal  Relief</strong></td>
        <td><?php echo $row_update['personal_relief']; ?></td>
      </tr>
          
  
      
      <tr>
        <td>NET TAX</td>
        <td><strong>&nbsp;&nbsp;&nbsp;<?php echo $row_update['nettax']; ?></strong></td>
      </tr>

<tr>
        <td><strong>NHIF </strong></td>
        <td><?php echo $row_update['nhif']; ?></td>
      </tr>
      <tr>
        <td><strong>NSSF </strong></td>
        <td><?php echo $row_update['nssf']; ?></td>
      </tr>



</table></td>
        <td width="250" valign="top"><table width="100" border="">
          

 <tr>
        <strong> Other Deductions </strong>
        
          <tr>


      <tr>
        <td><strong>DNW</strong></td>
        <td><?php echo $row_update['dnw']; ?></td>
      </tr>
      <tr>
        <td><strong>Meals</strong></td>
        <td><?php echo $row_update['meals']; ?></td>
      </tr>
      <tr>
        <td><strong>Advances</strong></td>
        <td><?php echo $row_update['advance']; ?></td>
      </tr>
      <tr>
        <td><strong>Loans</strong></td>
        <td><?php echo $row_update['loans']; ?></td>
      </tr>
 <tr>
        <td><strong>Others</strong></td>
        <td><?php echo $row_update['others']; ?></td>
      </tr>
        <tr>
 <td>Total Deductions</td>
        <td><strong>&nbsp;&nbsp;&nbsp;<?php echo $row_update['totaldeduc']; ?></strong></td>
      </tr>
      



        </table></td>
        </tr>
    </table>




       <table>
      
      <tr>
      
        <td>Net Income</td>
        <td><strong>Kshs.<?php echo $row_update['totall']; ?></strong></td>
      </tr>
    </table>
    <hr> 

<table width="747" border="1">

  <tr>
    <td align="center"><br />
      ............................................................<br />
      Acountant </td>
    <td align="center"><br />
      ............................................................<br />
      Finance Manager</td>
  </tr>

  </table>
</div>
</div>
</div>
</body>
</html>