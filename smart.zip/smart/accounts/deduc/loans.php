 <?php 
 include('../connection.php');
 $staff_id=$_GET['staff_id'];
 $result1 = mysql_query("SELECT * FROM loans WHERE staff_id='$staff_id'");

$row1= mysql_fetch_array($result1);
$lo=$row1['rate']; 
        $m=$row1['meals'];
        $o=$row1['other'];
        $ad=$row1['advance'];
$loans=$row1['loans'];

?>
<form method="post" action='loans.php'>
<table>

	<tr>
		<td>Loan Amount:</td>
		<td><input type="text" name="loans" value="<?php echo $loans; ?>"/></td>
	</tr>
	<tr>
		<td>Rate</td>
		<td><input type="text" name="rate" value="<?php echo $lo; ?>"/></td>
	</tr>
	<tr>
		<td>Advance Amount:</td>
		<td><input type="text" name="advance" value="<?php echo $ad; ?>"/></td>
	</tr>
	<tr>
		<td>Meal Amount:</td>
		<td><input type="text" name="meals" value="<?php echo$m; ?>"/></td>
	</tr>
	<tr>
		<tr>
		<td>Other Amount:</td>
		<td><input type="text" name="other" value="<?php echo $o; ?>"/></td>
	</tr>
		<td> Names </td>
		<td><input type="text" name="fname" value="<?php echo $_GET['fname'];?>" readonly/></td>
	</tr>
	<tr>
		<td>Staff Id</td>
		<td><input type="text" name="staff_id" value="<?php echo $_GET['staff_id'];?>" readonly/></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="submit" value="add" /></td>
	</tr>
</table>

</form>
<table border="1">
	
			
</table>

