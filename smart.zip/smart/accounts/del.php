<?php
  include("connection.php");  

	$id =$_REQUEST['id'];
	
	
	// sending query
	mysql_query("DELETE FROM config_nhif WHERE id = '$id'")
	or die(mysql_error());  	
	
	header("Location: nhifrate.php");
?>