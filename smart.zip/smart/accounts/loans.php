<?php
if (isset($_POST['submit']))
	{	   
	include 'connection.php';
	$date=date('M,Y');
	
			 		$staff_id=$_POST['staff_id'] ;
					$advance=$_POST['advance'] ;
					$loans=$_POST['loans'] ;
					$meals=$_POST['meals'] ;
					$other=$_POST['other'] ;
					$rate=$_POST['rate'] ;
					$fname=$_POST['fname'] ;
					$status ='active';

					$insert = ("UPDATE loans SET rate='$rate',fname='$fname',period='$date',loans='$loans',advance='$advance',meals='$meals',other='$other',status='$status' where staff_id='$staff_id'");
$qry = mysql_query($insert) or die(mysql_error());
if($insert)
	{
		echo "success";
		echo "<br />";
		echo "<a href=index.php> Home </a>";
						header("location:deduc.php");

	}
else
	{
		echo "failed";
	}
										
												
				      }
?>