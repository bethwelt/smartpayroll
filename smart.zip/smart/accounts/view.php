
<?php
session_start();
if (!isset($_SESSION['username'])) 
{
die(header('Location: ../index.php'));
}

include('connection.php');
?>

<?php

$id =$_REQUEST['id'];

$result = mysql_query("SELECT * FROM config_nhif WHERE id= '$id'");
$test = mysql_fetch_array($result);
if (!$result) 
		{
		die("Error: Data not found..");
		}
				$lower=$test['lower'] ;
				$higher= $test['higher'] ;					
				$amount=$test['amount'] ;
				//$CopyrightYear=$test['CopyrightYear'] ;

if(isset($_POST['save']))
{	
	$lower_save = $_POST['lower'];
	$higher_save = $_POST['higher'];
	$amount_save = $_POST['name'];
	//$copy_save = $_POST['copy'];

	mysql_query("UPDATE config_nhif SET lower ='$lower_save', higher ='$higher_save',
		 amount ='$amount_save' WHERE id= '$id'")
				or die(mysql_error()); 
	echo "Saved!";
	
	header("Location: nhifrate.php");			
}
//mysql_close($conn);
?>

<form method="post">
<table border='1' width='60%'>
	<tr>
		<td>FROM:</td>
		<td><input type="text" name="lower" value="<?php echo $lower ?>"/></td>
	</tr>
	<tr>
		<td>TO</td>
		<td><input type="text" name="higher" value="<?php echo $higher ?>"/></td>
	</tr>
	<tr>
		<td>AMOUNT</td>
		<td><input type="text" name="name" value="<?php echo $amount ?>"/></td>
	</tr>
	
	<tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="save" value="save" /></td>
	</tr>
</table>
