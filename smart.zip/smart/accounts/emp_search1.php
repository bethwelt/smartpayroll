<?php
include("connection.php");
isset( $_REQUEST['name'] ) ? $name=$_REQUEST['name'] : $name='';

$name = mysql_real_escape_string( $name );

if( empty( $name )){
	echo '<script> alert("Please EMPLOYEE IDNO!")</script>';
}else{
	$sql = "select * from  register_staff where idno like '%$name%'";
	
	$rs = mysql_query( $sql ) or die('Database Error: ' . mysql_error());
	$num = mysql_num_rows( $rs );
	
	if($num >= 1 ){
	echo "<div style='margin:10px; color:red; font-weight: bold;'>$num records found!</div>";
	echo "<table width='365' border ='1' cellspacing='5' cellpadding='5'>";
	echo"<tr>


<th>SID</th>

<th>Full Name</th>
<th>Emp Pin</th>

<th>Empl Pin</th>

<th>Department</th>
<th>BASIC</th>
<th>Bank Name</th>
<th>ACC NO</th>
<th>NSSF NO</th>
<th>NHIF NO</th>



<th>DELETE</th>
<th>UPDATE</th>




	</tr>";
	
	
		while($row = mysql_fetch_array( $rs )){?>




<tr class="<?php if(isset($classname)) echo $classname;?>">
<td><input type="checkbox" name="users[]" value="<?php echo $row["staff_id"]; ?>" ></td>
<?php

	echo "<td>" .$row['fname'] . "</td>";
	echo "<td>" .$row['emp_pin'] . "</td>";
	echo "<td>" .$row['empl_pin'] . "</td>";

	echo "<td>" .$row['department'] . "</td>";
	
	//echo "<td>" .$row['grade'] . "</td>";
	//echo "<td>" .$row['years'] . "</td>";
	echo "<td>" .$row['basic'] . "</td>";
	echo "<td>" .$row['bank'] . "</td>";
	echo "<td>" .$row['accno'] . "</td>";
	echo "<td>" .$row['nssfno'] . "</td>";
	echo "<td>" .$row['nhif'] . "</td>";
	

	echo "<td> <a href= delete.php?staff_id=".$row['staff_id'].">Delete</a>";
	echo "<td> <a href= up_staff.php?staff_id=".$row['staff_id'].">Update</a>";
	//echo "<td> <a href= im.php?staff_id=".$row['staff_id'].">Send Message</a>";


	?>
</tr>

<?php


  
		}
		    echo"</table>";
	}else{
		echo "<script> alert('No Result!')</script>";
	}
}
?>