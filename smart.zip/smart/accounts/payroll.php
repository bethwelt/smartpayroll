<?php
session_start();
if (!isset($_SESSION['username'])) 
{
die(header('Location: ../index.php'));
}

?>



<?php
$conn = mysql_connect("localhost","root","");
mysql_select_db("newsalary",$conn);
$result = mysql_query("SELECT * FROM register_staff where category='primary'");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home</title>
<link rel="stylesheet" href="../css/style.css" type="text/css" />
<link rel="stylesheet" href="style.css" type="text/css" />

<script type="text/javascript">
 	function proceed() 
	{
	  return confirm('update Payroll');
 	}
 </script>

</head>

<body>
	
<?php include("header.php");?>

<form name="frmUser1" method="post" action="">

<table>
<tr>


<th>&nbsp;&nbsp;&nbsp;&nbsp;STAFF ID</th>

<th>FULL NAME&nbsp;</th>
<th>&nbsp;&nbsp;&nbsp;&nbsp;EMP PIN&nbsp;</th>

<th>&nbsp;&nbsp;&nbsp;&nbsp;EMPL PIN&nbsp;</th>	

<th>&nbsp;&nbsp;&nbsp;DEPARTMENT&nbsp;</th>

<th>BASIC</th>
<th>BANK NAME&nbsp;</th>
<th>ACCOUNT NO&nbsp;</th>
<th>NHIF NO&nbsp;&nbsp;</th>
<th>NSSF NO&nbsp;&nbsp;</th>





</tr>
<?php
$i=0;
while($row = mysql_fetch_array($result)) {
if($i%2==0)
$classname="evenRow";
else
$classname="oddRow";
?>
<tr class="<?php if(isset($classname)) echo $classname;?>">
<td><input type="checkbox" name="id[]" value="<?php echo $row["id"]; ?>" ></td>
<?php

	echo "<td>" .$row['fname'] . "</td>";
	echo "<td>" .$row['emp_pin'] . "</td>";
	echo "<td>" .$row['empl_pin'] . "</td>";

	echo "<td>" .$row['department'] . "</td>";
	
	//echo "<td>" .$row['grade'] . "</td>";
	//echo "<td>" .$row['years'] . "</td>";
	echo "<td>" .$row['basic'] . "</td>";
	echo "<td>" .$row['bank'] . "</td>";
	echo "<td>" .$row['accno'] . "</td>";
	echo "<td>" .$row['nssfno'] . "</td>";
	echo "<td>" .$row['nhif'] . "</td>";
	
	


	//echo "<td> <a href= payslip.php?staff_id=".$row['staff_id']."&Salary_id=".$row['staff_id'].">Print</a>";
	?>
	<input name="staff_id" type="hidden" value="<?php echo $row['staff_id']; ?>" size="32" readonly="readonly">
        <input name="emp_pin" type="hidden" value="<?php echo $row['emp_pin']; ?>" size="32">
      <input name="empl_pin" type="hidden" value="<?php echo $row['empl_pin']; ?>">
      <input name="fname" type="hidden" value="<?php echo $row['fname']; ?>" />
      <input name="idno" type="hidden" value="<?php echo $row['idno']; ?>"/>
      <input name="basic" type="hidden" value="<?php echo $row['basic']; ?>"/>
      <input name="years" type="hidden" value="<?php echo $row['years']; ?>" />
      <input name="grade" type="hidden" value="<?php echo $row['grade']; ?>"/>
	  <input name="bank" type="hidden" value=" <?php echo $row['bank']; ?>" />
      <input name="accno" type="hidden" value="<?php echo $row['accno']; ?>" />
      <input name="nhif" type="hidden" value="<?php echo $row['nhif']; ?>" />
      <input name="nssfno" type="hidden" value="<?php echo $row['nssfno']; ?>"/>
      <?php $ran=rand(0,100000); 
      ?>
       <input name="ran" type="hidden" value="<?php echo $ran; ?>"/>
</tr>
<?php
$i++;
}
?>



  

      
   

<tr class="listheader">
<td colspan="20"><CENTER>&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" name="update" value="COMPUTE" onClick="setUpdateAction1();" /><CENTER></td>
</tr>
</table>




</div>
</div>
</body></html>