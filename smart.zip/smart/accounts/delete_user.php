<?php
$conn = mysql_connect("localhost","root","");
mysql_select_db("newsalary",$conn);
$rowCount = count($_POST["salary_id"]);
for($i=0;$i<$rowCount;$i++) {
mysql_query("DELETE FROM salary WHERE salary_id='" . $_POST["salary_id"][$i] . "'");
}
header("Location:print.php");
?>