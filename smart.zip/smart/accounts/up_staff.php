<?php

//database connection
include('connection.php');
include('../sanitise.php');
$staff_id = sanitise($_GET['staff_id']);
$qry =("SELECT * FROM register_staff WHERE staff_id = '$staff_id'");
$update = mysql_query($qry) or die(mysql_error());
$row_update = mysql_fetch_assoc($update);
$totalRows_update = mysql_num_rows($update);
?>
<?php
session_start();
if (!isset($_SESSION['username'])) 
{
die(header('Location: ../index.php'));
}

?>



<?php
$conn = mysql_connect("localhost","root","");
mysql_select_db("newsalary",$conn);
$result = mysql_query("SELECT * FROM register_staff");
?>



</head>



<form method="post" name="form1" action="up2.php">
  <table width="600" border="1" align="center">
    <tr>
      <td nowrap align="right">Staff No:</td>
      <td><input name="staff_id" type="text" value="<?php echo $row_update['staff_id']; ?>" size="32" readonly="readonly"></td>
    </tr>
      <tr>
      <td nowrap align="right">Full Name:</td>
      <td><input name="fname" type="text" value="<?php echo $row_update['fname']; ?>" size="32"></td>
    </tr>
    <tr>
      <td nowrap align="right">Employee Pin:</td>
      <td><input name="emp_pin" type="text" value="<?php echo $row_update['emp_pin']; ?>" size="32"></td>
    </tr>
    <tr>
      <td nowrap align="right">Employer Pin:</td>
      <td><input name="empl_pin" type="text" value="<?php echo $row_update['empl_pin']; ?>" size="32"></td>
    </tr>
  
  
    <tr>
       <tr>
    <td><strong>Company Branch</strong></td>
    <td><span id="spryselect3">
<select name="branch" id="branch">
<option value="" selected><?php echo $row_update['branch']; ?></option>
<option>branch 1</option>
<option>branch B</option>

</select>      

    </span></td>
  </tr>
    <td nowrap align="right">Department</td>
    <td><span id="spryselect3">
<select name="category" id="category">
<option value="" selected><?php echo $row_update['category']; ?></option>
<option value="primary" >Primary</option>
<option value="secondary" >Secondary</option>


</select>      

    </span></td>
  </tr>
     <tr>
      <td nowrap align="right">ID NO:</td>
      <td><input name="idno" type="text" value="<?php echo $row_update['idno']; ?>" size="32"></td>
    </tr>
     <tr>
    <td nowrap align="right">Department</td>
    <td><span id="spryselect3">
<select name="department" id="department">
<option value="" selected><?php echo $row_update['department']; ?></option>
<option value="Human Resources" >Human Resources</option>
<option value="I.T." >I.T.</option>
<option value="Accounting">Accounting</option>
<option value="Research">Research &amp; Development</option>
<option value="Administration">Administration</option>
<option value="Marketing">Marketing</option>
<option value="Production">Production</option>

</select>      

    </span></td>
  </tr>
  <tr>
    <td nowrap align="right">Position</td>
    <td><span id="spryselect2">
<select name="position" id="position">
<option value="" selected><?php echo $row_update['position']; ?></option>
<option value="Director">Director</option>
<option value="As. Director">As. Director</option>
<option value="Manager">Manager</option>
<option value="As.Manager">As. Manager</option>
<option value="Supervisor">Supervisor</option>
<option value="Head">Head</option>
<option value="Ass. Head">Ass. Head</option>
<option value="Clerk">Clerk</option>
</select>
      </span></td>
  </tr>
      <tr>
      <td nowrap align="right">Basic Salary</td>
      <td><input name="basic" type="text" value="<?php echo $row_update['basic']; ?>" size="32"></td>
    </tr>
    <tr>
      <td nowrap align="right">Years Spent:</td>
      <td><input name="years" type="text" value="<?php echo $row_update['years']; ?>" size="32"></td>
    </tr>
    <tr>
      <td nowrap align="right">Grade Level:</td>
      <td><input name="grade" type="text" value="<?php echo $row_update['grade']; ?>" size="32"></td>
    </tr>
       <tr>
   <td nowrap align="right">BANK NAME</td>
    <td>


<select name="bank" id="bank">
<option><?php echo $row_update['bank']; ?></option>
<option >NATIONAL</option>
<option>KCB</option>
<option >equity</option>

</select>


    </span></td>
  </tr>
      <tr>
      <td nowrap align="right">ACC NO</td>
      <td><input name="accno" type="text" value="<?php echo $row_update['accno']; ?>" size="32"></td>
    </tr>
    <tr>
      <td nowrap align="right">NHIF NO:</td>
      <td><input name="nhif" type="text" value="<?php echo $row_update['nhif']; ?>" size="32"></td>
    </tr>
    <tr>
      <td nowrap align="right">NSSF NO:</td>
      <td><input name="nssfno" type="text" value="<?php echo $row_update['nssfno']; ?>" size="32"></td>
    </tr>
    <tr>
      <td nowrap align="right">&nbsp;</td>
      <td><input type="submit" class="linkers" value="Update"></td>
    </tr>
  </table>
</form>
