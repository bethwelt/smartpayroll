<?php
session_start();
if (!isset($_SESSION['username'])) 
{
die(header('Location: ../index.php'));
}
?>
<?php 
 include('connection.php');
 //$staff_id=$_GET['staff_id'];
 $result1 = mysql_query("SELECT * FROM variables");

$row1= mysql_fetch_array($result1);
$a=$row1['housing']; 
        $b=$row1['long_service'];
        $c=$row1['tax'];
        $d=$row1['entertainment'];
$e=$row1['transport'];
  $f=$row1['nssf'];
$g=$row1['pension'];
  $h=$row1['personal_relief'];


?>


<form name="register" action="reg.php" method="post">
<table width="400" border="1" align="center">
  <tr>
    <td width="221"><strong>Full Names</strong></td>
    <td width="163"><span id="sprytextfield1">
          <input type="text" name="fname" id="email" />
   </span></td>
  </tr>
    <tr>
    <td width="221"><strong>Identity Number</strong></td>
    <td width="163"><span id="sprytextfield1">
          <input type="text" name="idno" id="email" />
   </span></td>
  </tr>
   <tr>
    <td width="221"><strong>Employer Pin:</strong></td>
    <td width="163"><span id="sprytextfield1">
          <input type="text" name="empl_pin" value="<?php echo $a ;?>"id="email" reaadonly />
   </span></td>
  </tr>
   <tr>
    <td><strong>Employee Category</strong></td>
    <td><span id="spryselect3">
<select name="category" id="category">

<option value="primary" selected >Primary </option>
<option value="secondary" >secondary</option>

</select>      

    </span></td>
  </tr>
    <tr>
    <td><strong>Company Branch</strong></td>
    <td><span id="spryselect3">
<select name="branch" id="branch">

<option value="Strawberry Events" selected>Strawberry Events</option>


</select>      

    </span></td>
  </tr>
   <tr>
    <td width="221"><strong>Employee Pin:</strong></td>
    <td width="163"><span id="sprytextfield1">
          <input type="text" name="emp_pin" id="email" />
   </span></td>
  </tr>
  <tr>
    <td><strong>Gender</strong></td>
    <td><span id="spryselect1">
  <select name="sex" id="sex">
  <option value="" selected>Select sex</option>
  <option value="Male" >Male</option>
  <option value="Female" >Female</option>
  </select>
      </span></td>
  </tr>
  <tr>
    <td><strong>Date of Birth</strong></td>
    <td>
      <input type="text" name="birthday" id="birthday" class="tcal"/>
</td>
  </tr>
  <tr>
    <td><strong>Department</strong></td>
    <td><span id="spryselect3">
<select name="department" id="department">
<option value="" selected>Select Department</option>
<option value="Administration">Administration</option>
<option value="transportations">Transportations</option>
<option value="catering" >Catering Services</option>
<option value="events" >Event Organisation</option>
</select>      

    </span></td>
  </tr>
  <tr>
    <td><strong>Position</strong></td>
    <td><input type="text" name="position" id="position" /></td>
  </tr>
   <tr>
    <td><strong>NSSF Number</strong></td>
    <td><span id="sprytextfield5">
      <input type="text" name="nssfno" id="grade" />
      </span></td>
  </tr>
   <tr>
    <td><strong>NHIF Number</strong></td>
    <td><span id="sprytextfield5">
      <input type="text" name="nhif" id="grade" />
      </span></td>
  </tr>
   <tr>
    <td><strong>BANK NAME</strong></td>
    <td>


<select name="bank" id="bank">
<option >Select Bank</option>
<option>NATIONAL</option>
<option >KCB</option>
<option >equity</option>

</select>


    </span></td>
  </tr>

   <tr>
    <td><strong>Account Number:</strong></td>
    <td><span id="sprytextfield5">
      <input type="text" name="accno" id="grade" />
     </span></td>
  </tr>
  <tr>
    <td><strong>Basic Salary</strong></td>
    <td><span id="sprytextfield6">
      <input type="text" name="basic" id="basic" />
      </span></td>
  </tr>
  <tr>
    <td><strong>Job Level/Category</strong></td>
    <td><span id="sprytextfield5">
      <input type="text" name="grade" id="grade" />
      </span></td>
  </tr>
  <tr>
    <td><strong>Experience</strong></td>
    <td><span id="sprytextfield6">
      <input type="text" name="years" id="years" />
  </span></td>
  </tr>

  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" name="submit" id="submit" value="Register Employee" /></td>
  </tr>
</table>

</form>
</div>
</div>
