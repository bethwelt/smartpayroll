function setUpdateAction() {
document.frmUser.action = "printselected.php";
document.frmUser.submit();
}
function setUpdateAction1() {
document.frmUser1.action = "p.php";
document.frmUser1.submit();
}
function setUpdateAction2() {
document.frmUser2.action = "p1.php";
document.frmUser2.submit();
}

function setDeleteAction() {
if(confirm("Are you sure want to delete these rows?")) {
document.frmUser.action = "delete_user.php";
document.frmUser.submit();
}
}
function setDeleteAction1() {
if(confirm("Are you sure want to compute these rows?")) {
document.frmUser.action = "pay.php";
document.frmUser.submit();
}
}