<?php
session_start();
if (!isset($_SESSION['username'])) 
{
die(header('Location: ../index.php'));
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Calculate Payroll</title>
<link rel="stylesheet" href="../css/style.css" type="text/css" />

</head>

<body><div id="outerwrapper1">
<div id="header"></div>
<?php include('header.php');?>
<div id="body">




  <?php
//database connection
include('connection.php');

//view record
$qry = mysql_query("SELECT * FROM register_staff");
echo "<table border='1' align='center'>
<tr>

<th>Staff ID</th>
<th>Full Name</th>
<th>Sex</th>
<th>Birthday</th>
<th>Department</th>
<th>Position</th>
<th>Grade</th>
<th>Years</th>
<th>Date Employed</th>
<th>Action</th>
</tr>";


while ($row = mysql_fetch_array($qry))

{
	echo "<form action='pay.php' method='post'>";
	echo "<tr>";
	//echo "<td>".$row['id']."</td>";
	echo "<td>" .$row['staff_id'] . "</td>";
	echo "<td>" .$row['fname'] . "</td>";
	echo "<td>" .$row['sex'] . "</td>";
	echo "<td>" .$row['birthday'] . "</td>";
	echo "<td>" .$row['department'] . "</td>";
	echo "<td>" .$row['position'] . "</td>";
	echo "<td>" .$row['grade'] . "</td>";
	echo "<td>" .$row['years'] . "</td>";
	echo "<td>" .$row['date_registered'] . "</td>";
  echo "<td><a rel='facebox' href= pay.php?id=".$row['id']." id='add'>Payroll</a>";

	

	echo "</tr>";

}
echo "<tr>";
	
	echo "<td><br></td>";
echo "</tr>";
echo "</table>";
echo "</form>";
echo "<a href=index.php>Go Home</a> <br />";
echo "<a href=payroll.php>Calculate Payroll</a>";
?>



</div>
</div>

<?php include('pagination.php');?>
</body>
</html>