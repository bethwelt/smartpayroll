  <a href="print.php">back</a> 

<hr>
<hr>
<table bgcolor="white" width="80%" align="center" border="1">
  <tr>
    <td>

    <script language="javascript">
function caaictpms()
{ 
  var disp_setting="toolbar=yes,location=no,directories=no,menubar=no,"; 
      disp_setting+="scrollbars=yes"; 
  var content_vlue = document.getElementById("print_content").innerHTML; 
  
  var docprint=window.open("","",disp_setting); 
   docprint.document.open(); 
   docprint.document.write('<html>'); 
      docprint.document.write('');
   docprint.document.write('</head><center><body onLoad="self.print()" style="width:400px; font-size:10px; margin-left:40px; -cell-padding:none;font: 12px/17px arial, sans-serif;color: rgb(50, 50, 50);">');
             
   docprint.document.write(content_vlue);          
   docprint.document.write('</body></center></html>'); 
   docprint.document.close(); 
   docprint.focus(); 
}
</script>
<div  id="print_content">
                          <center> <p class="pprint"> <a href="javascript:caaictpms()" >print</a></p></center>
<?php
$conn = mysql_connect("localhost","root","");
mysql_select_db("newsalary",$conn);
include('connection.php');
isset( $_REQUEST['salary_id'] ) ? $salary_id=$_REQUEST['salary_id'] : $salary_id='';

$salary_id = $salary_id;

if( empty( $salary_id )){
  echo '<script> alert("Please Select At  least One Employee To print")</script>';
?>
<script language="javascript">
setTimeout("top.location.href = 'print.php'",300);
</script>
<?php 
}


else{
  ?>
<?php
$rowCount = count($_POST["salary_id"]);
for($i=0;$i<$rowCount;$i++) {
$result = mysql_query("SELECT * FROM salary WHERE salary_id='" . $_POST["salary_id"][$i] . "'");
$row[$i]= mysql_fetch_array($result);

?>

<html>
<head>
<title>PRINT MULTILPE</title>
<link rel="stylesheet" type="text/css" href="styles.css" />
<link rel="stylesheet" href="../css/style1.css" type="text/css" />
</head>


<body bgcolor="grey">

<form name="frmUser" method="post" action="">
<div style="width:500px;">
<small>
<small>
  <table width="80%" border="">

  <tr>
    <small> <td colspan="1" align="center"><span class="text"><small>STRAWBERRY EVENTS LIMITED</small></span><br />
      <span class="text"><small>P.O BOX 30100-6021</small></span><br />
       <span class="text"><small>ELDORET.</small></span><br />
Website: www.strawberry.com Email: info@strawberry-events.com<br />
         
      <hr>
       <hr>
   <table>
  <tr>
    <?php $date=date('M,Y');?>
    <td><small>STAFF NO:</small></td>
    <td><?php echo $row[$i]['staff_id']; ?></td>
    <td><small>NAME:</small></td>
    <td width="181"><?php echo $row[$i]['fname']; ?></td>
    <td><small><small>EMPLOYEE PIN:</small></small></td>
    <td><?php echo $row[$i]['emp_pin']; ?></td>

  </tr>
   <tr>
   
    <td><small>EMPLOYER PIN:</small></td>
    <td width="81"><?php echo $row[$i]['empl_pin']; ?></td>
    
      <td width=""><small>DEPARTMENT:</small></td>
    <td width=""><?php echo $row[$i]['department']; ?></td>
    <td width=""><small>PERIOD:</small></td>
    <td><?php echo $row[$i]['period']; ?></td>
  </tr>
</table></small>

<table width="80%" border="">
  <tr>
   <table width="1000" border="">
<table width="20" border=""align="left"></table>
      <table width="266" border="" align="left">
         
      <tr>
        <td width="250"><strong>Basic Salary</strong></td>
        <td width="250"><?php echo $row[$i]['basic']; ?></td>
      </tr>
      <tr>
        <td><strong>Housing All.</strong></td>
        <td><?php echo $row[$i]['housing']; ?></td>
      </tr>
      <tr>
        <td><strong>Meal All.</strong></td>
        <td><?php echo $row[$i]['meal']; ?></td>
      </tr>
      <tr>
        <td><strong>Transport All.</strong></td>
        <td><?php echo $row[$i]['transport']; ?></td>
      </tr>
      <tr>
        <td><strong>Entertainment All.</strong></td>
        <td><?php echo $row[$i]['entertainment']; ?></td>
      </tr>
      <tr>
        <td><strong>Long Services</strong></td>
        <td><?php echo $row[$i]['long_service']; ?></td>
      </tr>
      


     
    </table>
              <table width="25" border=""align="left"></table>
     <table  border="" width="266" valign="top" align="left">
        
        <td><strong>Total income</strong></td>
        <td><?php echo $row[$i]['totalincome']; ?></td>
      </tr>
      <tr>
      <tr>
        <td><strong>Pension(NSSF)</strong></td>
        <td><?php echo $row[$i]['pension']; ?></td>
      </tr>


      <tr>

        <td><SMALL>Taxable Income</SMALL></td>
        <td><center><strong><?php echo $row[$i]['taxincome']; ?></strong></center></td>
      </tr>

<tr>
        
        <td><small>NET TAX</small></td>
        <td><?php echo $row[$i]['payee']; ?></td>
      </tr>
       <tr>
        <td><strong>Personal  Relief</strong></td>
        <td><?php echo $row[$i]['personal_relief']; ?></td>
</tr>

<tr>
<td><strong>Paye</strong></td>
        <td><strong><?php echo $row[$i]['nettax']; ?></strong></td>
      </tr>

          
    <tr>
        <td><strong>Nhif </strong></td>
        <td><?php echo $row[$i]['nhif']; ?></td>
      </tr>
      <tr>
        <td><strong>Nssf </strong></td>
        <td><?php echo $row[$i]['nssf']; ?></td>
      </tr>
          <table width="20" border=""align="left">



<table width="250" border=""align="left">
 
         <td><strong> Other Deductions </strong> </td>
        
      <tr>
        <td><strong>Days not worked</strong></td>
        <td><?php echo $row[$i]['dnw']; ?></td>
      </tr>
      <tr>
        <td><strong>Meals</strong></td>
        <td><?php echo $row[$i]['meals']; ?></td>
      </tr>
      <tr>
        <td><strong>Advances</strong></td>
        <td><?php echo $row[$i]['advance']; ?></td>
      </tr>
      <tr>
        <td><strong>Loans</strong></td>
        <td><?php echo $row[$i]['loans']; ?></td>
      </tr>
 <tr>
        <td><strong>Others Deductions</strong></td>
        <td><?php echo $row[$i]['loans']; ?></td>
      </tr>
 <tr>
  
 <tr>
        <td><strong>Total Deductions</strong></td>
        <td><?php echo $row[$i]['totaldeduc']; ?></td>
      </tr>


</table>
        </tr>
    </table>
 <table>
      
      <tr>
      
        <td>Net Income</td>
        <td><strong>Kshs.<?php echo $row[$i]['totall']; ?></strong></td>
      </tr>
    </table>
   

<small><table width="1000" border="1">

  <tr>
    <td align="center"><br />
      ............................................................<br />
      Acountant </td>
    <td align="center"><br />
      ............................................................<br />
      Finance Manager</td>
  </tr>

  </table></small>

</small>
  
<br>
<?php
}
}
?>

</div>
</div>

</form>
</td>
</tr>
</table>
</body></html> 
 


