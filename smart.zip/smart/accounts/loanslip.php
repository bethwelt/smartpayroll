<?php
session_start();
if (!isset($_SESSION['username'])) 
{
die(header('Location: ../index.php'));
}

?>
<?php
//database connection
include('connection.php');
include('../sanitise.php');
$staff_id = sanitise($_GET['staff_id']);
$id = sanitise($_GET['id']);
$qry =("SELECT * FROM loans WHERE staff_id = '$staff_id' AND id = '$id'");
$update = mysql_query($qry) or die(mysql_error());
$row_update = mysql_fetch_assoc($update);
$totalRows_update = mysql_num_rows($update);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Pay Slip</title>
<script language="javascript" type="text/javascript" >
        // Disen
        document.onselectstart=new Function('return false');
        function dMDown(e) {return false;}
        function dOClick() {return true;}
        document.onmousedown=dMDown;
        document.onclick=dOClick
        
        -->
    </script>
<style>
body, html
{
	margin:0;
	padding:0;
	font-family:"Lucida Sans Unicode", "Lucida Grande", sans-serif;
	font-size:11px;
	background-color:#fff;
}
#outerwrapper
{
	width:800px;
	height:auto;
	margin:auto;

}

#slip
{
	width:747px;
	height:auto;
	margin:auto;
	font-size: x-small;
}

#slip2
{
	width:418px;
	height:auto;
	margin-left:150px;
	margin-top:40px;
	text-align: right;
}

.text
{
	font-size:14px;
	font-family:Tahoma, Geneva, sans-serif;
	font-weight:bold;
}
</style>
</head>

<body>
<div id="outerwrapper">
<div id="slip">
<table width="447" border="1">
  <tr>
<td colspan="2" align="center"><span class="text"><small>STRAWBERRY EVENTS LIMITED</small></span><br />
      <span class="text"><small>P.O BOX 6021-30100</small></span><br />
       <span class="text"><small>ELDORET.</small></span><br />
      info@strawberry-events.com<br />
      <br />
<hr>
      <table width="100" border="0">
        <tr>
          <td align="center">LOANS SLIP</td>
        </tr>
      </td>
    </tr>
     <table>
  <tr>
    <?php $date=date('M,Y');?>
    <td><strong>STAFF NO:</strong></td>
    <td><?php echo $row_update['staff_id']; ?></td>
    <td><strong>NAME:</strong></td>
    <td width="181"><?php echo $row_update['fname']; ?></td>
    <td><strong>EMPLOYEES PIN:</strong></td>
    <td><?php echo $row_update['emp_pin']; ?></td>

  </tr>
   <tr>
   
    <td><strong>EMPLOYERS PIN:</strong></td>
    <td width="181"><?php echo $row_update['empl_pin']; ?></td>
    
      <td width="87"><strong>DEPARTMENT:</strong></td>
    <td width="368"><?php echo $row_update['department']; ?></td>
    <td><strong>PAYSLIP PERIOD:</strong></td>
    <td><?php echo $date; ?></td>
  </tr>
  <tr>
  
    <td width="83"><strong>POSITION:</strong></td>
    <td><?php echo $row_update['position']; ?></td>

    <td><strong>YEARS WORKED:</strong></td>
    <td><?php echo $row_update['years']; ?></td>
    
  </tr></table>
  <tr>
    <td colspan="4">
    <div id="slip2">
    <table width="418" border="1">
      <tr>
        <td width="180"><strong>Basic Salary</strong></td>
        <td width="222"><?php echo $row_update['basic']; ?></td>
      </tr>
      <tr>
        <td><strong>Loans</strong></td>
        <td><?php echo $row_update['loans']; ?></td>
      </tr>
      
      <tr>
        <td><strong>Advance</strong></td>
        <td><?php echo $row_update['advance']; ?></td>
      </tr>
      <tr>
        <td><strong>Meals</strong></td>
        <td><?php echo $row_update['meals']; ?></td>
      </tr>
      <tr>
        <td><strong>D Absent</strong></td>
        <td><?php echo $row_update['days']; ?></td>
      </tr>
      <tr>
        <td><strong>Rate</strong></td>
        <td><?php echo $row_update['rate']; ?></td>
 <tr>
        <td><strong>Others</strong></td>
        <td><?php echo $row_update['others']; ?></td>
      </tr>
      </tr>
<hr>
<?php
$d=$row_update['days'];
$r=$row_update['rate'];
$o=$row_update['others'];
$dnw=$d*$r;
?>
<tr>
        <td><strong>DNW Amount</strong></td>
        <td><?php echo $dnw; ?></td>
      </tr>


      <tr>
        <td><strong>Net Total</strong></td>
        <?Php
        $lo=$row_update['loans'];
        $ad=$row_update['advance'];
        $m=$row_update['meals'];

        $total=$lo+$ad+$m+$dnw+$o;
        ?>
        <td><strong>Kshs.<?php echo $total ?></strong></td>
      </tr>
    </table>
   </div></td>
  </tr>
</table>
<table width="576" border="1">
  <tr>
    <td align="center"><br />
      ............................................................<br />
      Acountant </td>
    <td align="center"><br />
      ............................................................<br />
      Finance Manager</td>
  </tr>
  </table>

Click <a href="printloan.php">here</a> to go back<br />
<a href="javascript:self.print()">Print This Page</a> <br />
</div>
</div>
</body>
</html>