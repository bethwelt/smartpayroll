<?php
if(isset($_POST['submit'])){
//database connection
include('connection.php');
include('../sanitise.php');
//select housing,transport, tax,entertainment and long_service values from variables table in the database. The data can be changed by the admin from the default values inputted by the designer.
$you = mysql_query("SELECT * FROM variables");
while ($row = mysql_fetch_array($you))
{
	$a = $row['housing'];
	$b = $row['transport'];
	$c = $row['tax'];
	$d = $row['entertainment'];
	$e = $row['long_service'];
	$f = $row['nssf'];
} 

$staff_id = sanitise($_POST['staff_id']);
$fname = sanitise($_POST['fname']);
$department = sanitise($_POST['department']);
$position = sanitise($_POST['position']);
//$grade = sanitise($_POST['grade']);
//$years = sanitise($_POST['years']);
$basic = sanitise($_POST['basic']);
$advance = sanitise($_POST['advance']);



//if nothing is found for a month, salary information is inserted into database.
	
		{
			$qry = "INSERT INTO advances (staff_id, fname, department, position, basic, advance) VALUES ('$staff_id','$fname','$department', '$position','$basic','$advance')";
			mysql_query($qry) or die(mysql_error());
			header('Location:printadvance.php');
		}
} 

?>