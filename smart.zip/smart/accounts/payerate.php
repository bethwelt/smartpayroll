<?php
session_start();
if (!isset($_SESSION['username'])) 
{
die(header('Location: ../index.php'));
}

include('connection.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Back up</title>
<link rel="stylesheet" href="../css/style.css" type="text/css" />
<link rel="stylesheet" href="../css/menu.css" type="text/css" />

<script type="text/javascript">
    function proceed() 
    {
      return confirm('Compute Payroll');
    }
 </script>

</head>

<body><div id="outerwrapper">
	
    <div id="header"></div>
<?php include("header.php");?><div id="body">
<center>
<form method="post">
<table border='1' width='60%'>

	<tr>
		<td>FROM:</td>
		<td><input type="number" name="lower" /></td>
	</tr>
	<tr>
		<td>TO:</td>
		<td><input type="number" name="higher" /></td>
	</tr>
	<tr>
		<td>AMOUNT CHARGED:</td>
		<td><input type="number" name="amount" /></td>
	</tr>
	<tr>
		<td>AMOUNT ADDED:</td>
		<td><input type="number" name="added" /></td>
	</tr>
	<tr>
		<td>RATE IN DECIMALS:</td>
		<td><input type="number" name="rate" /></td>
	</tr>
	<tr>
		<td>INITIAL CHARGE:</td>
		<td><input type="number" name="initial" /></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="submit" value="add" /></td>
	</tr>
</table>
<?php
if (isset($_POST['submit']))
	{	   
	
			 		$lower=$_POST['lower'] ;
					$higher= $_POST['higher'] ;					
					
		                       $added=$_POST['added'] ;
					$rate=$_POST['rate'] ;
	 	
	                         $initial=$lower-1;
												
		 mysql_query("INSERT INTO `config_paye`(lower,higher,added,rate,initial) 
		 VALUES ('$lower','$higher','$added','$rate','$initial')"); 
				
				
	        }
?>

</form>
<table border="1" width='60%'>
	<th>id</th>
	<th>Lower value</th>
	<th>higher value</th>
	<th>amount charged </th>
	<th>amount Added</th>
	<th>rate</th>
	<th>initial Value</th>
	<th>actions</th>
			<?php
			//include("db.php");
			
				
			$result=mysql_query("SELECT * FROM config_paye");
			
			while($test = mysql_fetch_array($result))
			{
				$id = $test['id'];	
				echo "<tr align='center'>";	
				echo"<td><font color='black'>" .$test['id']."</font></td>";
				echo"<td><font color='black'>" .$test['lower']."</font></td>";
				echo"<td><font color='black'>". $test['higher']. "</font></td>";
				echo"<td><font color='black'>". $test['amount']. "</font></td>";
				echo"<td><font color='black'>". $test['added']. "</font></td>";	
					
				echo"<td><font color='black'>". $test['rate']. "</font></td>";	
				echo"<td><font color='black'>". $test['initial']. "</font></td>";
				echo"<td> <a rel='facebox' href='viewp.php?id=$id' id='add'>Edit</a>";
				
				echo"<td> <a href ='delp.php?id=$id'><center>Delete</center></a>";
									
				echo "</tr>";
			}
			//mysql_close($conn);
			?>
</table>
</center>
</div>

<br>
<br>
<br>
</body>
</html>
