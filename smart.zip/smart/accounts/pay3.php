<?php
$conn = mysql_connect("localhost","root","");
mysql_select_db("newsalary",$conn);
$rowCount = count($_POST["users"]);
for($i=0;$i<$rowCount;$i++) {
mysql_query("SELECT FROM register_staff WHERE staff_id='" . $_POST["users"][$i] . "'");
}
header("Location:salprocessor2.php");
?>



</table>
</div>
</div>

</form>








