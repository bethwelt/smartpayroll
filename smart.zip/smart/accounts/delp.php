<?php
  include("connection.php");  

	$id =$_REQUEST['id'];
	
	
	// sending query
	mysql_query("DELETE FROM config_paye WHERE id = '$id'")
	or die(mysql_error());  	
	
	header("Location: payerate.php");
?>