 <?php 
 include('../connection.php');
 $staff_id=$_GET['staff_id'];
 $result1 = mysql_query("SELECT * FROM allowance WHERE staff_id='$staff_id'");

$row1= mysql_fetch_array($result1);
$h=$row1['house']; 
        $me=$row1['meall'];
        $ot=$row1['others'];
        $tr=$row1['travel'];
//$loans=$row1['loans'];

?>
<form method="post" action='addtr.php'>
<table>
<tr>
		<td>House Amount:</td>
		<td><input type="text" name="house" value="<?php echo $h; ?>"/></td>
	</tr>
	<tr>
		<td>Travel All:</td>
		<td><input type="text" name="travel" value="<?php echo $tr; ?>" /></td>
	</tr>	
	<tr>
		<td>Meals All:</td>
		<td><input type="text" name="meall"value="<?php echo $me; ?>" /></td>
	</tr>
		<tr>
		<td>Other All:</td>
		<td><input type="text" name="others" value="<?php echo $ot; ?>"/></td>
	</tr>
	<tr>
		<td> Names </td>
		<td><input type="text" name="fname" value="<?php echo $_GET['fname'];?>" readonly/></td>
	</tr>
	<tr>
		<td>Staff Id</td>
		<td><input type="text" name="staff_id" value="<?php echo $_GET['staff_id'];?>" readonly/></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="submit" value="add" /></td>
	</tr>
</table>

</form>
<table border="1">
	
		
</table>


