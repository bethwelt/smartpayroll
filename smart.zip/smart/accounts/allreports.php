<?php
session_start();
if (!isset($_SESSION['username'])) 
{
die(header('Location: ../index.php'));
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="stylesheet" href="../css/style.css" type="text/css" />
<link rel="stylesheet" href="style.css" type="text/css" />

<script type="text/javascript">
 	function proceed() 
	{
	  return confirm('update Payroll');
 	}
 </script>

</head>
<div id="outerwrapper">

  
<?php include("header.php");?>

<body><div id="outerwrapper">


<div id="header"></div>
<table>
  <tr>

    <td>
      <center><h5>  REPORTS</h5></center>

<div id="formdesign">

 <a rel='facebox' href='reports/viewrec.php' id='add'>Employee Reports</a>
 
<a rel='facebox' href='reports/payeprint.php' id='add'>Paye Reports</a>
  <a rel='facebox' href='reports/printnssf.php' id='add'>Nssf reports</a>
  <a rel='facebox' href='reports/printnif.php' id='add'>Nhif Reports</a>
    
 
 
</td>
</tr>

  <tr>
    <td>

  <a rel='facebox' href='reports/other.php' id='add'>Other Reports</a>
    <a rel='facebox' href='reports/meals.php' id='add'>meals Reports</a>
  
  <a rel='facebox' href='reports/advances.php' id='add'>Advances Reports</a>

<a rel='facebox' href='reports/loans.php' id='add'>Loans Reports</a>

</td>
</tr>


  <tr>
<td>

  <a rel='facebox' href='reports/otherall.php' id='add'>Other Allowance</a>
    <a rel='facebox' href='reports/meal_all.php' id='add'>meals Allowance</a>
  
  <a rel='facebox' href='reports/travel.php' id='add'>Travel Allowance</a>

<a rel='facebox' href='reports/house.php' id='add'>House Allowance</a>
</td>
</tr>

</table>
</div>
</div>
</body></html>
