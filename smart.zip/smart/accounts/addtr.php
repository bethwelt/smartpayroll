<?php
if (isset($_POST['submit']))
	{	   
	include 'connection.php';
	$date=date('M,Y');
	
			 		$staff_id=$_POST['staff_id'] ;
					$travel=$_POST['travel'] ;
					$house=$_POST['house'] ;
					$meal=$_POST['meall'] ;
					$other=$_POST['others'] ;
					$fname=$_POST['fname'] ;
					$status ='active';

					$insert = ("UPDATE allowance SET fname='$fname',period='$date',travel='$travel',house='$house',meall='$meal',others='$other',status='$status' where staff_id='$staff_id'");
$qry = mysql_query($insert) or die(mysql_error());
if($insert)
	{
		echo "success";
		echo "<br />";
		echo "<a href=index.php> Home </a>";
						header("location:all.php");

	}
else
	{
		echo "failed";
	}
										
												
				      }
?>