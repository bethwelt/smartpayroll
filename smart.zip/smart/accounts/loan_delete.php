<?php 
include('connection.php');
include('sanitise.php');
$id =sanitise( $_GET['id']);
$staff_id =sanitise( $_GET['staff_id']);
$qry = ("DELETE FROM loans WHERE id = '$id' AND staff_id = '$staff_id'");
$con = mysql_query($qry) or die(mysql_error());
if(!$con)
{
	echo "not deleted successfully";
	header('Location:view_staff.php');
}

else
{
	echo "staff has been successfully deleted";
	header('Location:printloan.php');
}
?>
