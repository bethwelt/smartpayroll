<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Calculate Salary</title>
<link rel="stylesheet" href="../css/style.css" type="text/css" />

<script type="text/javascript">
  function proceed() 
  {
    return confirm('Compute Payroll');
  }
 </script>
</head>

<body>

<?php include("header.php");?>

<?php

isset( $_REQUEST['id'] ) ? $id=$_REQUEST['id'] : $id='';

$id = $id;

if( empty( $id )){
  echo '<script> alert("Please Select At  least One Employee To Compute")</script>';
?>
<script language="javascript">
setTimeout("top.location.href = 'payroll.php'",300);
</script>
<?php 
}


else{


error_reporting(E_NOTICE);
include('connection.php');


include('../sanitise.php');

include('connection.php');
$rowCount = count($_REQUEST["id"]);
for($i=0;$i<$rowCount;$i++) {
  
   $id =$_POST["id"][$i];
$result = mysql_query("SELECT * FROM  register_staff WHERE id='$id'");
 //$staff_id =$row[$i]['staff_id'];
$row[$i]= mysql_fetch_array($result);
 $staff_id =$row[$i]['staff_id'];
$result1 = mysql_query("SELECT * FROM loans WHERE staff_id='$staff_id'");

$row1[$i]= mysql_fetch_array($result1);
$result2 = mysql_query("SELECT * FROM allowance WHERE staff_id='$staff_id'");

$row2[$i]= mysql_fetch_array($result2);

 $date=date('M,Y');
 
 //$staff_id =$row[$i]['staff_id'];

 //include('de.php');

 $lo=$row1[$i]['rate']; 
        $m=$row1[$i]['meals'];
        $o=$row1[$i]['other'];
        $ad=$row1[$i]['advance'];
        $loans=$row1[$i]['loans'];
   
        $deni=$loans-$lo;
        $balance=$deni;
$other=0;
$advance=0;
$meals=0;


  $a = $row2[$i]['house'];
  $b = $row2[$i]['travel'];
  $c = $row2[$i]['meall'];
  $d = $row2[$i]['others'];
  $e =0; //$row['long_service'];
$ran =$row[$i]['staff_id'];
$fname =$row[$i]['fname'];
$receiptno=$ran;
$department = sanitise($row[$i]['department']);
$position = sanitise($row[$i]['position']);
$grade = sanitise($row[$i]['grade']);
$years = sanitise($row[$i]['years']);
$basic = sanitise($row[$i]['basic']);
$meal =0;
$bank = sanitise($row[$i]['bank']);
$accno = sanitise($row[$i]['accno']);
$nh = sanitise($row[$i]['nhif']);
$nssfno = sanitise($row[$i]['nssfno']);
$emp_pin = sanitise($row[$i]['emp_pin']);
$idno = sanitise($row[$i]['idno']);
$empl_pin= sanitise($row[$i]['empl_pin']);


$dnw=0;

$nhif = 0;
$payee = 0;
$gross = 0;





$you = mysql_query("SELECT * FROM variables");
while ($row = mysql_fetch_array($you))
{

  $f = $row['nssf'];
  $g=$row['personal_relief'];
  $p=$row['pension'];
} 




//housing allowance is 15% of basic salary
$housing = ($a);

//transport allowance is 8% of basic salary
$transport = ($b);

//tax is 9% of basic salary
$tax = ($c * $basic);

    $entertainment = $d;

//staff who is above grade level 7, gets 2% of his/her salary has entertainment, if not, staff gets nothing
if ($grade > 7)
  { }
else
  {
    $entertainment = 0;
  }

//staff who has spent 15years and above gets 1.75% of his/her basic salary as long service allowance, if not, staff gets nothing
if ($years >= 15)
  {
    $long_service = $e;
  }
else 
  {
    $long_service = 0;
  }
//addition of basic salary and all allowances and subtraction of tax
  $otherincome=$long_service+$entertainment+$housing+$transport;
  $pension=$p;


  $gross=($basic-($pension) );

  $gp=$gross;
  $totalincome=($basic + $housing  + $transport + $entertainment + $long_service);

include('prate.php');
$nettax=($payee-$g);


  include("nrate.php");

$deductions=$nhif+$f+$ad+$nettax+$dnw+$lo+$m+$o;
$totaldeduc=$nettax+$nhif+$ad+$f+$dnw+$lo+$m+$o;
$totall = ($totalincome - $deductions);
//insert salary information into salary table of database.
//code here checks if salary has been computed for the month, it stops multiple submission for a month.
{
  $query = "SELECT * FROM salary WHERE id = '$id' AND month(date_s) = month(now())";
  $result = mysql_query($query);
  $num = mysql_num_rows($result);
  if($num>0)
    {
      echo "Staff Id $ran salary has been computed for this month";

      echo "<br />";
     
    }

//if nothing is found for a month, salary information is inserted into database.
  else
    {
       $insert = ("UPDATE loans SET balance='$balance',loans='$deni',rate='$lo',fname='$fname',period='$date',advance='$advance',meals='$meals',other='$other',status='Active' where staff_id='$staff_id'");
      $qry = mysql_query($insert) or die(mysql_error());
      $qry = "INSERT INTO salary (id,receiptno,idno,bank,accno,nhno,nssfno,others,period,staff_id,meals,empl_pin,totalincome,dnw,loans,otherincome,totaldeduc,taxincome,emp_pin,payee,fname, department, position, years, grade, basic, meal, housing, transport, entertainment,long_service, tax,nhif,nssf,advance,personal_relief,pension,nettax,totall) VALUES ('$id','$receiptno','$idno','$bank','$accno','$nh','$nssfno','$o','$date','$staff_id','$m','$empl_pin','$totalincome' , '$dnw','$lo','$otherincome'  , '$totaldeduc','$gross','$emp_pin','$payee','$fname','$department', '$position','$years','$grade','$basic','$meal', '$housing','$transport','$entertainment', '$long_service', '$tax','$nhif', '$f','$ad','$g','$pension','$nettax',$totall)";
      mysql_query($qry) or die(mysql_error());
     
      echo"COMPUTED SUCCESSFULLY";
 
    }
?>
<script language="javascript">
setTimeout("top.location.href = 'print.php'",300);
</script>
<?php

} 

}
 echo "<a href=payroll.php>Back</a>";

}
?>
</DIV>
</body></html>