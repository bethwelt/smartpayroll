 

    <script language="javascript">
function caaictpms()
{ 
  var disp_setting="toolbar=yes,location=no,directories=no,menubar=no,"; 
      disp_setting+="scrollbars=yes"; 
  var content_vlue = document.getElementById("print_content").innerHTML; 
  
  var docprint=window.open("","",disp_setting); 
   docprint.document.open(); 
   docprint.document.write('<html>'); 
      docprint.document.write('<title>PAYSLIP</title>');
   docprint.document.write('</head><center><body onLoad="self.print()" style="width:400px; font-size:5px; margin-left:30px; -cell-padding:none;font: 10px/17px Garamond;color: rgb(50, 50, 50);">');          
   docprint.document.write(content_vlue);          
   docprint.document.write('</body></center></html>'); 
   docprint.document.close(); 
   docprint.focus(); 
}
</script>





   <center> <p class="pprint"> <a href="javascript:caaictpms()" >print</a></p></center>
 


<div  id="print_content">
                         
                           

<?php
      include("../connection.php");
      
        
      $result=mysql_query("SELECT * FROM salary");
      
      while($test = mysql_fetch_array($result))
      {
      ?>

<small><table width="" border="">
  <tr>
    <small> <td colspan="1" align="center"><span class="text"><small>EXAMPLE COMPANY LIMITED</small></span><br />
      <span class="text"><small>P.O BOX 123--</small></span><br />
       <span class="text"><small>SAMPLE TOWN.</small></span><br />
      info@example.com<br />
      <hr>
   <table>
  <tr>
    <?php $date=date('M,Y');?>
    <td><small>STAFF NO:</small></td>
    <td><?php echo $test['staff_id']; ?></td>
    <td><small>NAME:</small></td>
    <td width="200"><?php echo $test['fname']; ?></td>
    <td><small><small>EMPLOYEE PIN:</small></small></td>
    <td><?php echo $test['emp_pin']; ?></td>

  </tr>
   <tr>
   
    <td><small>EMPLOYER PIN:</small></td>
    <td width="200"><?php echo $test['empl_pin']; ?></td>
    
      <td width=""><small>DEPARTMENT:</small></td>
    <td width="100"><?php echo $test['department']; ?></td>
    <td width=""><small>PERIOD:</small></td>
    <td><?php echo $test['period']; ?></td>
  </tr>
</table></small>

<table width="" border="">
  <tr>
   <table width="980" border="">
    


      <table width="250" border="" align="left">
         <tr>
        <td width="200"><strong>Basic/Allowances</strong></td>
        <td width="200"><strong>Amount</strong></td>
        
      </tr>
         
      <tr>
        <td width="200"><strong>Basic Salary</strong></td>
        <td width="200"><?php echo $test['basic']; ?></td>
      </tr>
      <tr>
        <td><strong>Housing All.</strong></td>
        <td><?php echo $test['housing']; ?></td>
      </tr>
      <tr>
        <td><strong>Meal All.</strong></td>
        <td><?php echo $test['meal']; ?></td>
      </tr>
      <tr>
        <td><strong>Transport All.</strong></td>
        <td><?php echo $test['transport']; ?></td>
      </tr>
      <tr>
        <td><strong>Enter All.</strong></td>
        <td><?php echo $test['entertainment']; ?></td>
      </tr>
      
   <tr>
        <td><strong>Total.Income</strong></td>
        <td><?php echo $test['totalincome']; ?></td>
      </tr>

     
    </table>
     <table  border="" width="250" valign="top" align="left">
     
       <tr>
        <td width="300"><strong>Tax/Paye</strong></td>
         <td width="100"><strong>Amount</strong></td>
        
      </tr>
      <tr>
        <td width="200"><strong>Employer Contribution</strong></td>
        <td><?php echo $test['pension']; ?></td>
      </tr>


      <tr>

        <td><SMALL>Taxable Income</SMALL></td>
        <td <td width="100"><center><strong><?php echo $test['taxincome']; ?></strong></center></td>
      </tr>

<tr>
        <td><strong>Paye</strong></td>
        <td><?php echo $test['payee']; ?></td>
      </tr>
       <tr>
        <td><strong>Personal  Relief</strong></td>
        <td><?php echo $test['personal_relief']; ?></td>
</tr>

<tr>
        <td><small>NET TAX</small></td>
        <td><strong><?php echo $test['nettax']; ?></strong></td>
      </tr>
     
    
        <tr>
        <td><strong>Nhif </strong></td>
        <td><?php echo $test['nhif']; ?></td>
      </tr>
      <tr>
        <td><strong>Nssf </strong></td>
        <td><?php echo $test['nssf']; ?></td>
      </tr>

<table width="200" border=""align="left">
  
          <table width="250" border=""align="left">

 <tr>
         <td width="200"><strong> Other Deductions </strong> </td>
          <td width="200"><strong>Amount</strong></td>
        
          <tr>


      <tr>
        <td><strong>Dnw</strong></td>
        <td width="100"><?php echo $test['dnw']; ?></td>
      </tr>
      <tr>
        <td><strong>Meals</strong></td>
        <td><?php echo $test['meals']; ?></td>
      </tr>
      <tr>
        <td><strong>Advances</strong></td>
        <td><?php echo $test['advance']; ?></td>
      </tr>
      <tr>
        <td><strong>Loans</strong></td>
        <td><?php echo $test['loans']; ?></td>
      </tr>
 <tr>
        <td><strong>Others</strong></td>
        <td><?php echo $test['loans']; ?></td>
      </tr>
 <tr>
	
 <tr>
        <td><strong>Total Deduc</strong></td>
        <td><?php echo $test['totaldeduc']; ?></td>
      </tr>


</table>
        </tr>
    </table>
 <table>
      
      <tr>
      
        <td>Net Income</td>
        <td><strong>Kshs.<?php echo $test['totall']; ?></strong></td>
      </tr>
    </table>
   

<small><table width="980" border="1">

  <tr>
    <td align="center"><br />
      ............................................................<br />
      Acountant </td>
    <td align="center"><br />
      ............................................................<br />
      Finance Manager</td>
  </tr>

  </table></small>

</small>
  <br>
  <br> 
    <?php
      }
      //mysql_close($conn);
      ?>
</div>


