<?php
session_start();
if (!isset($_SESSION['username'])) 
{
die(header('Location: ../index.php'));
}

?>



<?php
$conn = mysql_connect("localhost","root","");
mysql_select_db("newsalary",$conn);
$result = mysql_query("SELECT * FROM salary where month(date_s) = month(now())");
?>
<html>
<head>
<title>PAYE PRINT</title>



</head>



<center>
<br>

<div style='display:none;'>
  <img src="images/loader.gif" />
</div>

<form action="" name = "form">  
  <input type="text" name="name" id="fn" Placeholder="Enter Bank Name to search" style="width:300px; padding:8px;"/>
  <input type="submit" value="Search" id="search-btn" style="padding:8px;"/>
</form>
<br>
<center> <p class="pprint"> <a href="javascript:caaictpms()" >print</a></p></center>

 <script language="javascript">
function caaictpms()
{ 
  var disp_setting="toolbar=yes,location=no,directories=no,menubar=no,"; 
      disp_setting+="scrollbars=yes"; 
  var content_vlue = document.getElementById("print_content").innerHTML; 
  
  var docprint=window.open("","",disp_setting); 
   docprint.document.open(); 
   docprint.document.write('<html>'); 
      docprint.document.write('');
   docprint.document.write('</head><body onLoad="self.print()" style="width:400px; font-size:10px; margin-left:40px; -cell-padding:none;font: 12px/17px arial, sans-serif;color: rgb(50, 50, 50);">');
             
   docprint.document.write(content_vlue);          
   docprint.document.write('</body></html>'); 
   docprint.document.close(); 
   docprint.focus(); 
}
</script>
<div  id="print_content">

<div id = "s-results">
  <!-- Search results here! -->
</div>

<script type = "text/javascript">
$(document).ready(function(){
  $('#s-results').load('payes.php').show();
  
  
  $('#search-btn').click(function(){
    showValues();
  });
  
  $(function() {
    $('form').bind('submit',function(){
      showValues(); 
      return false; 
    });
  });
    
  function showValues() {
    $('#s-results').html('<img src="images/loader.gif" />');  
    
    $.post('payes.php', { name: form.name.value },
    
    function(result){
      $('#s-results').html(result).show();
    });
  }
    
});
</script>

</center>

    
                        
<form name="frmUser" method="post" action="">
<center><div style="width:1200px;">
<table border="0.5" cellpadding="10" cellspacing="5" width="600" class="tblListForm">
<tr class="listheader">

</div>
</center>
