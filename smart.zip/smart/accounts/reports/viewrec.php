

<?php
session_start();
if (!isset($_SESSION['username'])) 
{
die(header('Location: ../index.php'));
}

?>



<?php
$conn = mysql_connect("localhost","root","");
mysql_select_db("newsalary",$conn);
$result = mysql_query("SELECT * FROM register_staff");
?>
<html>
<head>
<title>VIEW EMPLOYEE</title>
<link rel="stylesheet" type="text/css" href="styles.css" />
<script language="javascript" src="users.js" type="text/javascript"></script>
<link rel="stylesheet" href="../css/style.css" type="text/css" />


</head>

<body>
	    <center> <p class="pprint"> <a href="javascript:caaictpms()" >print</a></p></center>

 <script language="javascript">
function caaictpms()
{ 
  var disp_setting="toolbar=yes,location=no,directories=no,menubar=no,"; 
      disp_setting+="scrollbars=yes"; 
  var content_vlue = document.getElementById("print_content").innerHTML; 
  
  var docprint=window.open("","",disp_setting); 
   docprint.document.open(); 
   docprint.document.write('<html>'); 
      docprint.document.write('');
   docprint.document.write('</head><body onLoad="self.print()" style="width:400px; font-size:10px; margin-left:40px; -cell-padding:none;font: 12px/17px arial, sans-serif;color: rgb(50, 50, 50);">');
             
   docprint.document.write(content_vlue);          
   docprint.document.write('</body></html>'); 
   docprint.document.close(); 
   docprint.focus(); 
}
</script>
<div  id="print_content">
<form name="frmUser1" method="post" action="">
<center><div style="width:1200px;">
<table border="1" cellpadding="10" cellspacing="5" width="600" class="tblListForm">
<tr class="listheader">

<th>SID</th>

<th>Full Name</th>
<th>Emp Pin</th>

<th>Empl Pin</th>
<th>ID NO</th>
<th>Department</th>

<th>BASIC</th>
<th>Bank Name</th>
<th>ACC NO</th>
<th>NSSF NO</th>
<th>NHIF NO</th>





</tr>
<?php
$i=0;
while($row = mysql_fetch_array($result)) {
if($i%2==0)
$classname="evenRow";
else
$classname="oddRow";
?>
<tr class="<?php if(isset($classname)) echo $classname;?>">
<td><?php echo $row["staff_id"]; ?></td>
<?php

	echo "<td>" .$row['fname'] . "</td>";
	echo "<td>" .$row['emp_pin'] . "</td>";
	echo "<td>" .$row['empl_pin'] . "</td>";
	echo "<td>" .$row['idno'] . "</td>";
	echo "<td>" .$row['department'] . "</td>";
	echo "<td>" .$row['basic'] . "</td>";
	echo "<td>" .$row['bank'] . "</td>";
	echo "<td>" .$row['accno'] . "</td>";
	echo "<td>" .$row['nssfno'] . "</td>";
	echo "<td>" .$row['nhif'] . "</td>";



	?>
</tr>
<?php
$i++;
}
?>
<BR>
<tr class="listheader">
<td colspan="50"></td>
</tr>
</table>
</form>

</body></html>






























