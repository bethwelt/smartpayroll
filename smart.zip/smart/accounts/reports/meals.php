<?php
session_start();
if (!isset($_SESSION['username'])) 
{
die(header('Location: ../index.php'));
}

?>



<?php
$conn = mysql_connect("localhost","root","");
mysql_select_db("newsalary",$conn);
$result = mysql_query("SELECT * FROM loans where month(date_s) = month(now())");
?>
<html>
<head>
<title>Loan Reports</title>



</head>


    <center> <p class="pprint"> <a href="javascript:caaictpms()" >print</a></p></center>

 <script language="javascript">
function caaictpms()
{ 
  var disp_setting="toolbar=yes,location=no,directories=no,menubar=no,"; 
      disp_setting+="scrollbars=yes"; 
  var content_vlue = document.getElementById("print_content").innerHTML; 
  
  var docprint=window.open("","",disp_setting); 
   docprint.document.open(); 
   docprint.document.write('<html>'); 
      docprint.document.write('');
   docprint.document.write('</head><body onLoad="self.print()" style="width:400px; font-size:10px; margin-left:40px; -cell-padding:none;font: 12px/17px arial, sans-serif;color: rgb(50, 50, 50);">');
             
   docprint.document.write(content_vlue);          
   docprint.document.write('</body></html>'); 
   docprint.document.close(); 
   docprint.focus(); 
}
</script>
<div  id="print_content">
                        
<form name="frmUser" method="post" action="">
<center><div style="width:1200px;">
<table border="0.5" cellpadding="10" cellspacing="5" width="600" class="tblListForm">
<tr class="listheader">
<td></td>

<th>STAFF ID</th>

<th>&nbsp;FULL NAME&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
<th>&nbsp;Period&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
<th>Date&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
<th>Meal Deductions&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>






</tr>
<?php
$i=0;
while($row = mysql_fetch_array($result)) {
if($i%2==0)
$classname="evenRow";
else
$classname="oddRow";
?>
<tr class="<?php if(isset($classname)) echo $classname;?>">

<?php
echo "<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>";
  echo "<td>" .$row['staff_id'] . "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>";
  echo "<td>" .$row['fname'] . "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>";
  echo "<td>" .$row['period'] . "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>";
  echo "<td>" .$row['date_s'] . "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>";
  

  echo "<td>" .$row['meals']. "</td>";
  
  

  
  ?>
</tr>
<?php
$i++;
}
?>
<TR>
  <BR>
  </TR>
  
<BR>
  <?php
  $qry = "SELECT count(*),  sum(meals), monthname(date_s) FROM loans where month(date_s) = month(now())GROUP BY month(date_s)";
$run = mysql_query($qry) or die(mysql_error());

  ?>

<?php while ($row = mysql_fetch_array($run)) {?>
        <tr class="<?php if(isset($classname)) echo $classname;?>">
          <STRONG>
          <td>TOTALS</td></STRONG>
        <td><?php echo $row['count(*)']; ?></td>
        <td>####</td>
        <td>####</td>
          <td>####</td>
      
  
        <td>Kshs.<?php echo round($row['sum(meals)']); ?></td>
        
      
        
      </tr><?php }?>
<BR>
<tr class="listheader">
<td colspan="50"></td>
</tr>
</table>
</form>
</center>
