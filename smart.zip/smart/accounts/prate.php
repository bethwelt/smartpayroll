
			<?php
			
			

				
			$result=mysql_query("SELECT lower,higher,added,initial,rate FROM config_paye where $gross BETWEEN lower AND higher");
			
			while($test = mysql_fetch_array($result))
			{
		
			
		        $lw1=$test['lower'];
			 $high=$test['higher'];
		
			$rat=$test['rate'];	
			 $init=$test['initial'];
                         $add=$test['added'];

			if($gross<=11164)
         {

$payee=0;
$g=0;
$payee=0;

} 
else
{

				$payee=(($gross-$init)*$rat)+$add;
}

				

			}
	
			?>

