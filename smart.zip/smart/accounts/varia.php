<?php
if(isset($_POST['submit'])){
include('connection.php');
include('sanitise.php');
$housing = sanitise($_POST['housing']);
$transport = sanitise($_POST['transport']);
$entertainment = sanitise($_POST['entertainment']);
$long_service = sanitise($_POST['long_service']);
$tax = sanitise($_POST['tax']);
$pension = sanitise($_POST['pension']);
$nssf = sanitise($_POST['nssf']);
$personal_relief = sanitise($_POST['personal_relief']);

$insert = ("UPDATE variables SET pension ='$pension',housing = '$housing',personal_relief = '$personal_relief', transport = '$transport', tax = '$tax', entertainment = '$entertainment', long_service = '$long_service' ,nssf= '$nssf'");
$qry = mysql_query($insert) or die(mysql_error());
if($insert)
	{
		echo "success";
		echo "<br />";
		echo "<a href=index.php> Home </a>";
		header("location:index.php");
	}
else
	{
		echo "failed";
	}
}
?>