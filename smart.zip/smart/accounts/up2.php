<?php
include('connection.php');
include('../sanitise.php');
$staff_id = sanitise($_POST['staff_id']);
$branch= sanitise($_POST['branch']);
$fname= sanitise($_POST['fname']);
$department= sanitise($_POST['department']);
$position= sanitise($_POST['position']);
$years= sanitise($_POST['years']);
$grade= sanitise($_POST['grade']);
$basic= sanitise($_POST['basic']);
$category= sanitise($_POST['category']);
$empl_pin= sanitise($_POST['empl_pin']);
$emp_pin= sanitise($_POST['emp_pin']);
$bank= sanitise($_POST['bank']);
$accno= sanitise($_POST['accno']);
$nssfno= sanitise($_POST['nssfno']);
$idno= sanitise($_POST['idno']);
$nhif= sanitise($_POST['nhif']);



$qry =("UPDATE register_staff SET branch = '$branch',fname = '$fname',category= '$category',empl_pin = '$empl_pin',emp_pin = '$emp_pin', department = '$department', bank = '$bank',accno = '$accno', nhif='$nhif', nssfno = '$nssfno', idno = '$idno', position = '$position', years = '$years', grade = '$grade', basic = '$basic' WHERE staff_id = '$staff_id'");
$run = mysql_query($qry) or die(mysql_error());
if($run)
	{
		echo "Staff $fname update has been completed successfully";
header('Location:view_staff.php');	}

else
	{
		echo "not successful .die or (mysql_error())";
	}

?>