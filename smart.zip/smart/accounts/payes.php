<?php
include("connection.php");
isset( $_REQUEST['name'] ) ? $name=$_REQUEST['name'] : $name='';

$name = mysql_real_escape_string( $name );

if( empty( $name )){
	echo '<script> alert("Please search something!")</script>';
}else{
	$sql = "select * from salary where bank like '%$name%' and  month(date_s) = month(now())";
	
	$rs = mysql_query( $sql ) or die('Database Error: ' . mysql_error());
	$num = mysql_num_rows( $rs );
	
	if($num >= 1 ){
	echo "<div style='margin:10px; color:red; font-weight: bold;'>$num records found!</div>";
	echo "<table width='365' border ='1' cellspacing='5' cellpadding='5'>";
	echo"<tr>

<th>STAFF ID</th>

<th>&nbsp;FULL NAME&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
<th>&nbsp;ID NUMBER&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>

<th>ACCOUNT NUMBER&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
<th>BANK</th>
<th>NET INCOME</th>









	</tr>";
	
	
		while($row = mysql_fetch_array( $rs )){?>




<tr class="<?php if(isset($classname)) echo $classname;?>">

<?php
echo "<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>";
  echo "<td>" .$row['staff_id'] . "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>";
	echo "<td>" .$row['fname'] . "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>";
	echo "<td>" .$row['idno'] . "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>";
	echo "<td>" .$row['accno'] . "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>";
	echo "<td>" .$row['bank'] . "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>";

	echo "<td>" .$row['totall']. "</td>";
	?>
</tr>

<BR>

	<?php
	$qry = "SELECT count(*), sum(basic), sum(meal), sum(nhif), sum(nssf), sum(pension), sum(loans), sum(dnw),sum(payee), sum(totall), monthname(date_s) FROM salary where month(date_s) = month(now()) and bank like '%$name%' GROUP BY month(date_s)";
$run = mysql_query($qry) or die(mysql_error());

	?>

<?php while ($row = mysql_fetch_array($run)) {?>
      	<tr class="<?php if(isset($classname)) echo $classname;?>">
      		<STRONG>
      		<td>TOTALS</td></STRONG>
        <td><?php echo $row['count(*)']; ?></td>
        <td>#</td>
        <td>#</td>
        <td>##</td>
        <td>##</td>
  
        <td>Kshs.<?php echo round($row['sum(totall)']); ?></td>
        </tr>
       <?php  
   }
       ?>

<?php


  
		}
		    echo"</table>";

	}
	else{
		echo "<script> alert('No Result!')</script>";
	}
}
?>
