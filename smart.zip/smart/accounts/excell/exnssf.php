<?php
			include("../connection.php");
	function convert_to_csv($input_array, $output_file_name, $delimiter)
{
	/** open raw memory as file, no need for temp files, be careful not to run out of memory thought */
	$f = fopen('php://memory', 'w');
	/** loop through array  */
	foreach ($input_array as $line) {
		/** default php csv handler **/
		fputcsv($f, $line, $delimiter);
	}
	/** rewrind the "file" with the csv lines **/
	fseek($f, 0);
	/** modify header to be downloadable csv file **/
	header('Content-Type: application/csv');
	header('Content-Disposition: attachement; filename="' . $output_file_name . '";');
	/** Send file to browser for download */
	echo stream_get_contents($f);
}
$result=mysql_query("SELECT * FROM salary where month(date_s) = month(now())");
/** Array to convert to csv */
	while($test = mysql_fetch_array($result))
			{
	
	        $id=$test['staff_id'];
			$lw=$test['fname'];
			$hi=$test['idno'];
			$init=$test['nssfno'];
			$am=$test['pension'];
			$ns=$test['nssf'];


$array_to_csv = Array(Array($id,$lw,$hi,$init,$am,$ns));

convert_to_csv($array_to_csv, 'product_detail.csv', ',');
}



?> 

