<?php
 
$host = 'localhost'; // MYSQL database host adress
$db = 'newsalary'; // MYSQL database name
$user = 'root'; // Mysql Datbase user
$pass = ''; // Mysql Datbase password
 
// Connect to the database
$link = mysql_connect($host, $user, $pass);
mysql_select_db($db);
 
require 'exel.php';
 
$table=""; // this is the tablename that you want to export to csv from mysql.
 
exportMysqlToCsv($table);
 
?>