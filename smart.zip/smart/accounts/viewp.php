<?php
session_start();
if (!isset($_SESSION['username'])) 
{
die(header('Location: ../index.php'));
}

include('connection.php');
?>



<?php
//require("db.php");
$id =$_REQUEST['id'];

$result = mysql_query("SELECT * FROM config_paye WHERE id= '$id'");
$test = mysql_fetch_array($result);
if (!$result) 
		{
		die("Error: Data not found..");
		}
				$lower=$test['lower'] ;
				$higher= $test['higher'] ;					
				//$amount=$test['amount'] ;
				$added=$test['added'] ;
				$rate=$test['rate'] ;
				$initial=$test['initial'] ;

if(isset($_POST['save']))
{	
	$lower_save = $_POST['lower'];
	$higher_save = $_POST['higher'];
	//$amount_save = $_POST['amount'];
	$added_save = $_POST['added'];
	$initial_save = $_POST['initial'];
	$rate_save = $_POST['rate'];

	mysql_query("UPDATE config_paye SET lower ='$lower_save', higher ='$higher_save', added='$added_save', initial='$initial_save' , rate='$rate_save'  WHERE id= '$id'")
				or die(mysql_error()); 
	echo "Saved!";
	
	header("Location: payerate.php");			
}
//mysql_close($conn);
?>


<form method="post">
<table border='1' width='60%'>
	<tr>
		<td>FROM AMOUNT LESS THAN</td>
		<td><input type="text" name="lower" value="<?php echo $lower ?>"/></td>
	</tr>
	<tr>
		<td>TO AMOUNT LESS THAN</td>
		<td><input type="text" name="higher" value="<?php echo $higher ?>"/></td>
	</tr>
	
	<tr>
		<td>AMOUNT ADDED</td>
		<td><input type="text" name="added" value="<?php echo $added ?>"/></td>
	</tr>
		<tr>
		<td>RATE IN DECIMAL</td>
		<td><input type="text" name="rate" value="<?php echo $rate ?>"/></td>
	</tr>
		<tr>
		<td>INITIAL VALUE</td>
		<td><input type="text" name="initial" value="<?php echo $initial ?>"/></td>
	</tr>
	
	<tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="save" value="save" /></td>
	</tr>
</table>
</form>