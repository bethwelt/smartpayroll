<?php
session_start();
if (!isset($_SESSION['username'])) 
{
die(header('Location: ../index.php'));
}
include('../sanitise.php');
$month = sanitise($_GET['month']);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>View month</title>
<link rel="stylesheet" href="../css/style.css" type="text/css" />


</head>
<body>
<?php include('header.php');?>
<?php
//database connection
include('connection.php');

//view record
$qry = mysql_query("SELECT * FROM salary WHERE monthname(date_s) = '$month'");
echo "<table border='1' bgcolor='lightgrey' align='center' width='100%'>
<tr>
<th>Staff ID</th>
<th>Full Name</th>
<th>Department</th>
<th>Position</th>
<th>Grade</th>
<th>Years</th>
<th>Basic</th>


<th>Paye</th>
<th>Net Income</th>
<th>Date</th>
</tr>";


while ($row = mysql_fetch_array($qry))
{
	echo "<tr>";
	echo "<td>" .$row['staff_id'] . "</td>";
	echo "<td>" .$row['fname'] . "</td>";
	echo "<td>" .$row['department'] . "</td>";
	echo "<td>" .$row['position'] . "</td>";
	echo "<td>" .$row['grade'] . "</td>";
	echo "<td>" .$row['years'] . "</td>";
	echo "<td>" .$row['basic'] . "</td>";

	
	echo "<td>" .$row['nettax'] . "</td>";
	echo "<td>" .$row['totall'] . "</td>";
	echo "<td>" .$row['date_s'] . "</td>";
	echo "</tr>";
}
echo "</table>";
echo "<a href=index.php>Go Home</a>  <br />";
?>


</div>
</body>
</html>