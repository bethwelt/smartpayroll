


<?php
if (isset($_POST['submit']))
{
//database connection
include('connection.php');
include('../sanitise.php');
	$digits =7;
function randStrGen1($digits){
    $result = "";
    $chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    $charArray = str_split($chars);
    for($i = 0; $i < $digits; $i++){
	    $randItem = array_rand($charArray);
	    $result .= "".$charArray[$randItem];
    }
    return $result;
   
}
$pre='EMP';
 $staff_id=$pre."-".randStrGen1($digits);
$branch = sanitise($_POST['branch']);
$fname = sanitise($_POST['fname']);
$sex = sanitise($_POST['sex']);
$empl_pin = sanitise($_POST['empl_pin']);
$emp_pin = sanitise($_POST['emp_pin']);
$accno = sanitise($_POST['accno']);
$bank = sanitise($_POST['bank']);
$nssfno = sanitise($_POST['nssfno']);
$nhif = sanitise($_POST['nhif']);
$idno = sanitise($_POST['idno']);
$bank = sanitise($_POST['bank']);
$category = sanitise($_POST['category']);
$birthday = sanitise($_POST['birthday']);
$department = sanitise($_POST['department']);
$position = sanitise($_POST['position']);
$grade = sanitise($_POST['grade']);
$years = sanitise($_POST['years']);
$basic = sanitise($_POST['basic']);


//$username = sanitise($_POST['username']);
//$password = sanitise($_POST['password']);
$submit = sanitise($_POST['submit']);


	$qry1 = "INSERT INTO loans (staff_id,fname) VALUES ('$staff_id','$fname')";
	mysql_query($qry1);
$qry2 = "INSERT INTO allowance(staff_id,fname) VALUES ('$staff_id','$fname')";
mysql_query($qry2);


//record insertion
$qry = "INSERT INTO register_staff (staff_id,branch,category,basic,idno,fname, sex, birthday, department, position, grade, years,empl_pin,emp_pin,nssfno,accno,bank,nhif) VALUES ('$staff_id','$branch','$category','$basic','$idno','$fname', '$sex', '$birthday', '$department', '$position', '$grade', '$years', '$empl_pin', '$emp_pin','$nssfno','$accno','$bank','$nhif')";
mysql_query($qry);
if($qry)
	{
		echo "Staff has been successfully registered";
		echo "<a href=view_staff.php> View </a>";

                  header('Location: view_staff.php');

	}

else
	{
		echo "Registration was not completed, please try again";
		echo "<a href=index.php>Home</a>";
	}


}


?>
