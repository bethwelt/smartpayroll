<?php
include("connection.php");
isset( $_REQUEST['name'] ) ? $name=$_REQUEST['name'] : $name='';

$name = mysql_real_escape_string( $name );

if( empty( $name )){
	echo '<script> alert("Please Enter NHIF NO!")</script>';
}else{
	$sql = "select * from salary where nhno like '%$name%'";
	
	$rs = mysql_query( $sql ) or die('Database Error: ' . mysql_error());
	$num = mysql_num_rows( $rs );
	
	if($num >= 1 ){
	echo "<div style='margin:10px; color:red; font-weight: bold;'>$num records found!</div>";
	echo "<table width='365' border ='1' cellspacing='5' cellpadding='5'>";
	echo"<tr>


<th>SID</th>

<th>Full Name</th>
<th>Emp Pin</th>

<th>Basic&nbsp;</th>

<th>Meals&nbsp;&nbsp;</th>
<th>NHIF&nbsp;</th>
<th>NSSF&nbsp;</th>
<th>Advances</th>
<th>Loans</th>
<th>Days not worked</th>
<th>Paye</th>
<th>Net Income</th>

<th>Action</th>




	</tr>";
	
	
		while($row = mysql_fetch_array( $rs )){?>




<tr class="<?php if(isset($classname)) echo $classname;?>">

<?php
 echo "<td>" .$row['salary_id'] . "</td>";
	echo "<td>" .$row['fname'] . "</td>";
	echo "<td>" .$row['emp_pin'] . "</td>";
	//echo "<td>" .$row['empl_pin'] . "</td>";

	//echo "<td>" .$row['department'] . "</td>";
	//echo "<td>" .$row['position'] . "</td>";
	//echo "<td>" .$row['grade'] . "</td>";
	//echo "<td>" .$row['years'] . "</td>";
	echo "<td>" .$row['basic'] . "</td>";
	
	echo "<td>" .$row['meals'] . "</td>";
	echo "<td>" .$row['nhif'] . "</td>";
	echo "<td>" .$row['nssf'] . "</td>";
	echo "<td>" .$row['advance']. "</td>";
	echo "<td>" .$row['loans']. "</td>";
		echo "<td>" .$row['dnw']. "</td>";
	echo "<td>" .$row['payee']. "</td>";
	echo "<td>" .$row['totall']. "</td>";

	echo "<td> <a href= payslip.php?staff_id=".$row['staff_id']."&salary_id=".$row['salary_id'].">Print</a>";
	?>
</tr>


<?php


  
		}
		    echo"</table>";
	}else{
		echo "<script> alert('No Result!')</script>";
	}
}
?>