<?php 
 include('connection.php');
 //$staff_id=$_GET['staff_id'];
 $result1 = mysql_query("SELECT * FROM variables");

$row1= mysql_fetch_array($result1);
$a=$row1['housing']; 
        $b=$row1['long_service'];
        $c=$row1['tax'];
        $d=$row1['entertainment'];
$e=$row1['transport'];
  $f=$row1['nssf'];
$g=$row1['pension'];
  $h=$row1['personal_relief'];


?>
    <td width="186" valign="top"><form name="variables" action="varia.php" method="post">
    <table width="213" border="1">
      <tr>
        <td colspan="2"><strong>Update payment Variables</strong></td>
        </tr>
      <tr>
        <td width="89">Employer PIN</td>
        <td width="108"><span id="sprytextfield1">
        <input type="text" name="housing" id="housing" value="<?php echo $a ;?>"/>
        <span class="textfieldRequiredMsg"> </span></span></td>
      </tr>
      <tr>
        <td>COMPANY Name</td>
        <td><span id="sprytextfield2">
        <input type="text" name="transport" id="transport" value="<?php echo $e ;?>"/>
        <span class="textfieldRequiredMsg"> </span></span></td>
      </tr>
      <tr>
        <td>Entertainment</td>
        <td><span id="sprytextfield3">
        <input type="text" name="entertainment" id="entertainment" value="<?php echo $d ;?>" />
        <span class="textfieldRequiredMsg"> </span></span></td>
      </tr>
      <tr>
        <td>Long Service</td>
        <td><span id="sprytextfield4">
        <input type="text" name="long_service" id="long_service" value="<?php echo $b ;?>"/>
        <span class="textfieldRequiredMsg"> </span></span></td>
      </tr>
      <tr>
        <td>Secondry Employe Tax</td>
        <td><span id="sprytextfield5">
          <input type="text" name="tax" id="tax" value="<?php echo $c ;?>" />
</span></td>
      </tr>
       <tr>
        <td>Pension</td>
        <td><span id="sprytextfield5">
          <input type="text" name="pension" id="pension" value="<?php echo $g ;?>" />
</span></td>
      </tr>
          <tr>
        <td>NSSF AMOUNT</td>
        <td><span id="sprytextfield5">
          <input type="text" name="nssf" id="nssf" value="<?php echo $f ;?>" />
</span></td>
      </tr>
          <tr>
        <td>Personal Relief</td>
        <td><span id="sprytextfield5">
          <input type="text" name="personal_relief" id="personal_relief" value="<?php echo $h;?>"/>
</span></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td><input type="submit" name="submit" id="submit" value="Submit/></td>
      </tr>