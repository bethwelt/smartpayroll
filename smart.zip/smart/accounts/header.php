
<?php include("menu.php");?>
<br>
<br>
<link rel="stylesheet" type="text/css" href="../CSS/styles.css" />
<script language="javascript" src="users.js" type="text/javascript"></script>
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
   <script src="lib/jquery.js" type="text/javascript"></script>
  <script src="src/facebox.js" type="text/javascript"></script>
  <script type="text/javascript">
    jQuery(document).ready(function($) {
      $('a[rel*=facebox]').facebox({
        loadingImage : 'src/loading.gif',
        closeImage   : 'src/closelabel.png'
      })
    })
  </script>

<div id="formdesign">
  <a rel="facebox" href="reg_staff.php" id="add">Add Employee</a>
<a rel="facebox" href="variables.php" id="add">Update Variables</a>
<BR><BR>
<BR>




