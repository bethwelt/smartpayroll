<?php
if(isset($_POST['submit'])){
//database connection
include('connection.php');
include('sanitise.php');
//select housing,transport, tax,entertainment and long_service values from variables table in the database. The data can be changed by the admin from the default values inputted by the designer.


$staff_id = sanitise($_POST['staff_id']);
$fname = sanitise($_POST['fname']);
$department = sanitise($_POST['department']);
//$position = sanitise($_POST['position']);
//$grade = sanitise($_POST['grade']);
//$years = sanitise($_POST['years']);
$basic = sanitise($_POST['basic']);
$meals = sanitise($_POST['meals']);
$loans = sanitise($_POST['loans']);
$days = sanitise($_POST['days']);
$rate = sanitise($_POST['rate']);
$advance = sanitise($_POST['advance']);
$period = sanitise($_POST['period']);
$others = sanitise($_POST['others']);




//if nothing is found for a month, salary information is inserted into database.
	
		{
			$qry = "INSERT INTO loans (others,staff_id,period,meals,advance,days,rate,fname, department, position, basic,loans) VALUES ('$others','$staff_id','$period','$meals','$advance','$days','$rate','$fname','$department', '$position','$basic','$loans')";
			mysql_query($qry) or die(mysql_error());
			header('Location:printloan.php');
		}
} 

?>