<?php
if(isset($_POST['submit'])){
//database connection
include('connection.php');
include('sanitise.php');
//select housing,transport, tax,entertainment and long_service values from variables table in the database. The data can be changed by the admin from the default values inputted by the designer.


$staff_id = sanitise($_POST['staff_id']);
$fname = sanitise($_POST['fname']);
$department = sanitise($_POST['department']);
//$position = sanitise($_POST['position']);
//$grade = sanitise($_POST['grade']);
//$years = sanitise($_POST['years']);
$basic = sanitise($_POST['basic']);
$house = sanitise($_POST['house']);
$hard = sanitise($_POST['hard']);
$transit = sanitise($_POST['transit']);
//$rate = sanitise($_POST['rate']);
//$advance = sanitise($_POST['advance']);
$period = sanitise($_POST['period']);
$others = sanitise($_POST['others']);




//if nothing is found for a month, salary information is inserted into database.
	
		{
			$qry = "INSERT INTO allowances(others,staff_id,period,house,hard,transit,fname, department, position, basic) VALUES ('$others','$staff_id','$period','$house','$hard','$transit','$fname','$department', '$position','$basic')";
			mysql_query($qry) or die(mysql_error());
			header('Location:all.php');
		}
} 

?>