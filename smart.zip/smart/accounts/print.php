<?php
session_start();
if (!isset($_SESSION['username'])) 
{
die(header('Location: ../index.php'));
}

?>

<?php
$conn = mysql_connect("localhost","root","");
mysql_select_db("newsalary",$conn);

$result = mysql_query("SELECT * FROM salary where month(date_s) = month(now())");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home</title>
<link rel="stylesheet" href="../css/style.css" type="text/css" />
<link rel="stylesheet" href="style.css" type="text/css" />

<script type="text/javascript">
 	function proceed() 
	{
	  return confirm('update Payroll');
 	}
 </script>

</head>

<body>
<?php include("header.php");?>
<form name="frmUser" method="post" action="">
<div style="width:AUTO;">
<table  class="tblListForm">
<tr class="listheader">
<th>select</th>
<th>SID</th>

<th>Full Name</th>

<th>Basic&nbsp;</th>
<th>House&nbsp;&nbsp;</th>
<th>Travel&nbsp;</th>
<th>Meals&nbsp;&nbsp;</th>
<th>NHIF&nbsp;</th>
<th>NSSF&nbsp;</th>
<th>Advances</th>
<th>Loans</th>

<th>Paye</th>
<th>Net Income</th>

<th>Action</th>

</tr>
<?php
$i=0;
while($row = mysql_fetch_array($result)) {
if($i%2==0)
$classname="evenRow";
else
$classname="oddRow";
?>
<tr class="<?php if(isset($classname)) echo $classname;?>">
	<td><input type="checkbox" name="salary_id[]" value="<?php echo $row["salary_id"]; ?>" ></td>
<?php
 echo "<td>" .$row['staff_id'] . "</td>";
	echo "<td>" .$row['fname'] . "</td>";
	//echo "<td>" .$row['emp_pin'] . "</td>";
	//echo "<td>" .$row['empl_pin'] . "</td>";

	//echo "<td>" .$row['department'] . "</td>";
	//echo "<td>" .$row['position'] . "</td>";
	//echo "<td>" .$row['grade'] . "</td>";
	//echo "<td>" .$row['years'] . "</td>";
	echo "<td>" .$row['basic'] . "</td>";
	echo "<td>" .$row['housing'] . "</td>";
	echo "<td>" .$row['transport'] . "</td>";
	
	echo "<td>" .$row['meals'] . "</td>";
	echo "<td>" .$row['nhif'] . "</td>";
	echo "<td>" .$row['nssf'] . "</td>";
	echo "<td>" .$row['advance']. "</td>";
	echo "<td>" .$row['loans']. "</td>";
		
	echo "<td>" .$row['payee']. "</td>";
	echo "<td>" .$row['totall']. "</td>";

	echo "<td> <a rel='facebox' href=payslip.php?staff_id=".$row['staff_id']."&salary_id=".$row['salary_id']." id='add'>Print</a>";
	?>
</tr>
<?php
$i++;
}
?>
<TR>
	<BR>
	</TR>
	
<BR>
	<?php
	$qry = "SELECT count(*), sum(basic),sum(housing),sum(transport), sum(meal), sum(nhif), sum(nssf), sum(advance), sum(loans), sum(dnw),sum(payee), sum(totall), monthname(date_s) FROM salary where month(date_s) = month(now()) GROUP BY month(date_s) ";
$run = mysql_query($qry) or die(mysql_error());

	?>

<?php while ($row = mysql_fetch_array($run)) {?>
      	<tr class="<?php if(isset($classname)) echo $classname;?>">
      		<STRONG>
      		<td>TOTALS</td></STRONG>

        <td>Total No: <?php echo $row['count(*)']; ?></td>
        <td>##</td>
        
        
        <td>Kshs.<?php echo round($row['sum(basic)']); ?></td>
              <td>Kshs.<?php echo round($row['sum(housing)']); ?></td>
                    <td>Kshs.<?php echo round($row['sum(transport)']); ?></td>
        <td>Kshs.<?php echo round($row['sum(meal)']); ?></td>
        <td>Kshs.<?php echo round($row['sum(nhif)']); ?></td>
        <td>Kshs.<?php echo round($row['sum(nssf)']); ?></td>
        <td>Kshs.<?php echo round($row['sum(advance)']); ?></td>
        <td>Kshs.<?php echo round($row['sum(loans)']); ?></td>
       
        
        <td>Kshs.<?php echo round($row['sum(payee)']); ?></td>
        <td>Kshs.<?php echo round($row['sum(totall)']); ?></td>
        
     	</tr><?php }?>
     	<tr class="listheader">
<td colspan="4"><input type="button" name="update" value="Print Selected" onClick="setUpdateAction();" />&nbsp;&nbsp;&nbsp;&nbsp; <input type="button" name="delete" value="Delete"  onClick="setDeleteAction();" /></td>
</STRONG></tr>
<?php include('pagination.php');?>
</table>
</form>
</div>
</div>
</body></html>
<hr>
<?php include('footer.php');?> 