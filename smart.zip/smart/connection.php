<?php 
$connection=mysql_connect('localhost', 'root', '');
$selectdb=mysql_select_db('newsalary');

?>

