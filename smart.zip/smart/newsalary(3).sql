-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 04, 2016 at 02:15 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `newsalary`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(2, 'admin', 'admin'),
(3, 'too', 'bethwel1');

-- --------------------------------------------------------

--
-- Table structure for table `admin_outbox`
--

CREATE TABLE IF NOT EXISTS `admin_outbox` (
  `ao_id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(100) NOT NULL,
  `sender` varchar(100) NOT NULL,
  `receiver` varchar(100) NOT NULL,
  `msg_subject` text NOT NULL,
  `msg_msg` text NOT NULL,
  `sent_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ao_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `advances`
--

CREATE TABLE IF NOT EXISTS `advances` (
  `staff_id` varchar(40) NOT NULL,
  `fname` varchar(40) NOT NULL,
  `department` varchar(40) NOT NULL,
  `position` varchar(40) NOT NULL,
  `basic` decimal(10,2) NOT NULL,
  `advance` decimal(10,2) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_s` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `allowance`
--

CREATE TABLE IF NOT EXISTS `allowance` (
  `staff_id` varchar(40) NOT NULL,
  `fname` varchar(40) NOT NULL,
  `travel` decimal(10,2) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_s` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `period` varchar(40) NOT NULL,
  `status` varchar(40) NOT NULL,
  `others` decimal(10,2) NOT NULL,
  `meall` decimal(10,2) NOT NULL,
  `house` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `allowance`
--

INSERT INTO `allowance` (`staff_id`, `fname`, `travel`, `id`, `date_s`, `period`, `status`, `others`, `meall`, `house`) VALUES
('EMP-R9N8T46', 'sample', '0.00', 1, '2016-04-01 14:51:23', '', '', '0.00', '0.00', '0.00'),
('EMP-E2R016E', 'DDD', '0.00', 2, '2016-04-01 15:23:04', '', '', '0.00', '0.00', '0.00'),
('EMP-YA59QXV', 'RAEL CHERUIYOT', '0.00', 3, '2016-04-01 15:24:29', '', '', '0.00', '0.00', '0.00'),
('EMP-3798EY9', 'd', '0.00', 4, '2016-04-01 16:16:26', '', '', '0.00', '0.00', '0.00'),
('EMP-A9TJ2XW', 'bb', '0.00', 5, '2016-04-01 16:30:57', '', '', '0.00', '0.00', '0.00'),
('EMP-2RL1WF0', 'ddd', '0.00', 6, '2016-04-01 16:34:19', '', '', '0.00', '0.00', '0.00'),
('EMP-C9TJ2XW', 'Cheruiyot Rael', '0.00', 7, '2016-04-03 09:04:39', '', '', '0.00', '0.00', '0.00'),
('EMP-XO8RHKC', 'Musungu Zekasi', '0.00', 8, '2016-04-20 08:16:58', '', '', '0.00', '0.00', '0.00'),
('EMP-F25K072', 'Moraa Naomi', '0.00', 9, '2016-04-20 08:19:09', '', '', '0.00', '0.00', '0.00'),
('EMP-0KA40ZI', 'Philip Keter', '0.00', 10, '2016-04-20 09:03:04', '', '', '0.00', '0.00', '0.00'),
('EMP-962S45O', 'Lokiru Joshuoa', '0.00', 11, '2016-04-20 09:06:58', '', '', '0.00', '0.00', '0.00'),
('EMP-L683UQ0', 'Momanyi Wilfred', '0.00', 12, '2016-04-20 09:08:55', '', '', '0.00', '0.00', '0.00'),
('EMP-W1D7BK9', 'Muhia Dominic', '0.00', 13, '2016-04-20 09:10:09', '', '', '0.00', '0.00', '0.00'),
('EMP-D21FOA5', 'Okoth Raphael', '0.00', 14, '2016-04-20 09:12:50', '', '', '0.00', '0.00', '0.00'),
('EMP-14QG3Q1', 'Boit Naomy', '0.00', 15, '2016-04-20 09:24:52', '', '', '0.00', '0.00', '0.00'),
('EMP-57GN5RX', 'Yabei Joseph', '0.00', 16, '2016-04-20 09:26:10', '', '', '0.00', '0.00', '0.00'),
('EMP-6M5D4K6', 'Nyamboke Elizabeth', '0.00', 17, '2016-04-20 09:28:23', '', '', '0.00', '0.00', '0.00'),
('EMP-49O93Z1', 'Libale Nelson', '0.00', 18, '2016-04-20 09:30:42', '', '', '0.00', '0.00', '0.00'),
('EMP-P83I14F', 'Albela George', '0.00', 19, '2016-04-20 09:32:48', '', '', '0.00', '0.00', '0.00'),
('EMP-AD81J7G', 'Kogo Julius', '0.00', 20, '2016-04-20 09:56:40', '', '', '0.00', '0.00', '0.00'),
('EMP-D40B5DQ', 'Musungu Simon', '0.00', 21, '2016-04-20 09:58:49', '', '', '0.00', '0.00', '0.00'),
('EMP-HFOPB5F', 'Cheruiyot Rael', '0.00', 22, '2016-04-20 10:02:11', '', '', '0.00', '0.00', '0.00'),
('EMP-99O7DIH', 'Kosgei Josphat', '0.00', 23, '2016-04-20 10:04:56', '', '', '0.00', '0.00', '0.00'),
('EMP-S9186X7', 'Edward', '0.00', 24, '2016-04-20 10:05:53', '', '', '0.00', '0.00', '0.00'),
('EMP-6P9B34R', 'Meshack', '0.00', 25, '2016-04-20 10:06:45', '', '', '0.00', '0.00', '0.00'),
('EMP-2L1JX1E', 'Hillary', '0.00', 26, '2016-04-20 10:07:47', '', '', '0.00', '0.00', '0.00'),
('EMP-734DB27', 'Karama Ken', '0.00', 27, '2016-04-20 10:08:40', '', '', '0.00', '0.00', '0.00'),
('EMP-9XCC2EI', '', '0.00', 28, '2016-06-04 09:43:35', '', '', '0.00', '0.00', '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `allowances`
--

CREATE TABLE IF NOT EXISTS `allowances` (
  `staff_id` varchar(40) NOT NULL,
  `fname` varchar(40) NOT NULL,
  `department` varchar(40) NOT NULL,
  `position` varchar(40) NOT NULL,
  `basic` decimal(10,2) NOT NULL,
  `date_s` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `house` decimal(10,2) NOT NULL,
  `hard` decimal(10,2) NOT NULL,
  `transit` decimal(10,2) NOT NULL,
  `period` varchar(40) NOT NULL,
  `empl_pin` varchar(40) NOT NULL,
  `emp_pin` varchar(40) NOT NULL,
  `others` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `code`
--

CREATE TABLE IF NOT EXISTS `code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Code` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `code`
--

INSERT INTO `code` (`id`, `Code`) VALUES
(1, 'EMP');

-- --------------------------------------------------------

--
-- Table structure for table `config_nhif`
--

CREATE TABLE IF NOT EXISTS `config_nhif` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lower` decimal(10,2) NOT NULL,
  `higher` decimal(10,2) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `config_nhif`
--

INSERT INTO `config_nhif` (`id`, `lower`, `higher`, `amount`) VALUES
(3, '0.00', '5999.00', '150.00'),
(4, '6000.00', '7999.00', '300.00'),
(5, '8000.00', '11999.00', '400.00'),
(6, '12000.00', '14999.00', '500.00'),
(7, '15000.00', '19999.00', '600.00'),
(9, '20000.00', '24999.00', '750.00'),
(10, '25000.00', '29999.00', '850.00'),
(11, '30000.00', '34999.00', '900.00'),
(12, '40000.00', '44999.00', '1000.00'),
(13, '45000.00', '49999.00', '1100.00'),
(14, '50000.00', '59999.00', '1200.00'),
(15, '60000.00', '69999.00', '1300.00'),
(16, '70000.00', '79999.00', '1400.00'),
(17, '80000.00', '89999.00', '1500.00'),
(18, '90000.00', '99999.00', '1600.00'),
(19, '100000.00', '1000000.00', '1700.00'),
(20, '35000.00', '39999.00', '950.00'),
(24, '0.00', '0.00', '0.00'),
(25, '0.00', '0.00', '0.00'),
(26, '0.00', '0.00', '0.00'),
(27, '222.00', '0.00', '0.00'),
(28, '222.00', '0.00', '0.00'),
(29, '222.00', '0.00', '0.00'),
(30, '222.00', '0.00', '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `config_paye`
--

CREATE TABLE IF NOT EXISTS `config_paye` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lower` decimal(10,2) NOT NULL,
  `higher` decimal(10,2) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `initial` decimal(10,2) NOT NULL,
  `rate` varchar(11) NOT NULL,
  `added` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `config_paye`
--

INSERT INTO `config_paye` (`id`, `lower`, `higher`, `amount`, `initial`, `rate`, `added`) VALUES
(2, '0.00', '11164.00', '0.00', '0.00', '0.1', '1016.00'),
(3, '11165.00', '19741.00', '0.00', '11164.00', '0.15', '1436.00'),
(4, '19742.00', '29317.00', '0.00', '19741.00', '0.2', '2452.00'),
(5, '29318.00', '38893.00', '0.00', '29317.00', '0.25', '4367.00'),
(6, '38894.00', '10000000.00', '0.00', '38893.00', '0.3', '6761.00');

-- --------------------------------------------------------

--
-- Table structure for table `loans`
--

CREATE TABLE IF NOT EXISTS `loans` (
  `staff_id` varchar(40) NOT NULL,
  `fname` varchar(40) NOT NULL,
  `loans` decimal(10,2) NOT NULL,
  `date_s` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `advance` decimal(10,2) NOT NULL,
  `rate` decimal(10,2) NOT NULL,
  `meals` decimal(10,2) NOT NULL,
  `period` varchar(40) NOT NULL,
  `other` decimal(10,2) NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `status` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `loans`
--

INSERT INTO `loans` (`staff_id`, `fname`, `loans`, `date_s`, `id`, `advance`, `rate`, `meals`, `period`, `other`, `balance`, `status`) VALUES
('EMP-R9N8T46', 'sample', '0.00', '2016-04-01 14:51:34', 1, '0.00', '0.00', '0.00', 'Apr,2016', '0.00', '0.00', 'Active'),
('EMP-E2R016E', 'DDD', '0.00', '2016-04-01 15:23:04', 2, '0.00', '0.00', '0.00', '', '0.00', '0.00', ''),
('EMP-YA59QXV', 'RAEL CHERUIYOT', '1400.00', '2016-04-02 10:26:38', 3, '0.00', '200.00', '0.00', 'Apr,2016', '0.00', '1400.00', 'active'),
('EMP-3798EY9', 'd', '0.00', '2016-04-01 16:16:37', 4, '0.00', '0.00', '0.00', 'Apr,2016', '0.00', '0.00', 'Active'),
('EMP-A9TJ2XW', 'bb', '0.00', '2016-04-01 16:31:06', 5, '0.00', '0.00', '0.00', 'Apr,2016', '0.00', '0.00', 'Active'),
('EMP-2RL1WF0', 'ddd', '0.00', '2016-04-01 16:34:31', 6, '0.00', '0.00', '0.00', 'Apr,2016', '0.00', '0.00', 'Active'),
('EMP-C9TJ2XW', 'Cheruiyot Rael', '0.00', '2016-04-03 09:05:16', 7, '0.00', '0.00', '0.00', 'Apr,2016', '0.00', '0.00', 'Active'),
('EMP-XO8RHKC', 'Musungu Zekasi', '0.00', '2016-04-20 08:16:58', 8, '0.00', '0.00', '0.00', '', '0.00', '0.00', ''),
('EMP-F25K072', 'Moraa Naomi', '0.00', '2016-04-20 08:19:09', 9, '0.00', '0.00', '0.00', '', '0.00', '0.00', ''),
('EMP-0KA40ZI', 'Philip Keter', '0.00', '2016-04-20 09:03:04', 10, '0.00', '0.00', '0.00', '', '0.00', '0.00', ''),
('EMP-962S45O', 'Lokiru Joshuoa', '0.00', '2016-04-20 09:06:58', 11, '0.00', '0.00', '0.00', '', '0.00', '0.00', ''),
('EMP-L683UQ0', 'Momanyi Wilfred', '0.00', '2016-04-20 09:08:55', 12, '0.00', '0.00', '0.00', '', '0.00', '0.00', ''),
('EMP-W1D7BK9', 'Muhia Dominic', '0.00', '2016-04-20 09:10:09', 13, '0.00', '0.00', '0.00', '', '0.00', '0.00', ''),
('EMP-D21FOA5', 'Okoth Raphael', '0.00', '2016-04-20 09:12:50', 14, '0.00', '0.00', '0.00', '', '0.00', '0.00', ''),
('EMP-14QG3Q1', 'Boit Naomy', '0.00', '2016-04-20 09:24:52', 15, '0.00', '0.00', '0.00', '', '0.00', '0.00', ''),
('EMP-57GN5RX', 'Yabei Joseph', '0.00', '2016-04-20 09:26:10', 16, '0.00', '0.00', '0.00', '', '0.00', '0.00', ''),
('EMP-6M5D4K6', 'Nyamboke Elizabeth', '0.00', '2016-04-20 09:28:23', 17, '0.00', '0.00', '0.00', '', '0.00', '0.00', ''),
('EMP-49O93Z1', 'Libale Nelson', '0.00', '2016-04-20 09:30:42', 18, '0.00', '0.00', '0.00', '', '0.00', '0.00', ''),
('EMP-P83I14F', 'Albela George', '0.00', '2016-04-20 09:32:48', 19, '0.00', '0.00', '0.00', '', '0.00', '0.00', ''),
('EMP-AD81J7G', 'Kogo Julius', '0.00', '2016-04-20 09:56:40', 20, '0.00', '0.00', '0.00', '', '0.00', '0.00', ''),
('EMP-D40B5DQ', 'Musungu Simon', '0.00', '2016-04-20 09:58:49', 21, '0.00', '0.00', '0.00', '', '0.00', '0.00', ''),
('EMP-HFOPB5F', 'Cheruiyot Rael', '0.00', '2016-04-20 10:02:11', 22, '0.00', '0.00', '0.00', '', '0.00', '0.00', ''),
('EMP-99O7DIH', 'Kosgei Josphat', '0.00', '2016-04-20 10:04:56', 23, '0.00', '0.00', '0.00', '', '0.00', '0.00', ''),
('EMP-S9186X7', 'Edward', '0.00', '2016-04-20 10:05:53', 24, '0.00', '0.00', '0.00', '', '0.00', '0.00', ''),
('EMP-6P9B34R', 'Meshack', '0.00', '2016-06-04 09:46:31', 25, '0.00', '0.00', '0.00', 'Jun,2016', '0.00', '0.00', 'Active'),
('EMP-2L1JX1E', 'Hillary', '0.00', '2016-06-04 09:44:36', 26, '0.00', '0.00', '0.00', 'Jun,2016', '0.00', '0.00', 'Active'),
('EMP-734DB27', 'Karama Ken', '0.00', '2016-04-20 10:08:40', 27, '0.00', '0.00', '0.00', '', '0.00', '0.00', ''),
('EMP-9XCC2EI', '', '0.00', '2016-06-04 09:43:35', 28, '0.00', '0.00', '0.00', '', '0.00', '0.00', '');

-- --------------------------------------------------------

--
-- Table structure for table `register_staff`
--

CREATE TABLE IF NOT EXISTS `register_staff` (
  `staff_id` varchar(20) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `sex` varchar(50) NOT NULL,
  `birthday` date NOT NULL,
  `department` varchar(50) NOT NULL,
  `position` varchar(50) NOT NULL,
  `grade` varchar(50) NOT NULL,
  `years` varchar(50) NOT NULL,
  `date_registered` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `emp_pin` varchar(40) NOT NULL,
  `empl_pin` varchar(40) NOT NULL,
  `nssfno` varchar(40) NOT NULL,
  `accno` varchar(40) NOT NULL,
  `bank` varchar(40) NOT NULL,
  `nhif` varchar(40) NOT NULL,
  `idno` varchar(40) NOT NULL,
  `basic` decimal(10,2) NOT NULL,
  `category` varchar(40) NOT NULL DEFAULT 'primary',
  `branch` varchar(40) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `register_staff`
--

INSERT INTO `register_staff` (`staff_id`, `fname`, `sex`, `birthday`, `department`, `position`, `grade`, `years`, `date_registered`, `emp_pin`, `empl_pin`, `nssfno`, `accno`, `bank`, `nhif`, `idno`, `basic`, `category`, `branch`, `id`) VALUES
('EMP-XO8RHKC', 'Musungu Zekasi', 'Male', '0000-00-00', '', '', '', '', '2016-04-20 08:16:58', 'P051565352L', 'P051565352L', '', '', 'KCB', '', '32039604', '8600.00', '', '', 6),
('EMP-F25K072', 'Moraa Naomi', '', '0000-00-00', 'catering', '', '', '', '2016-04-20 08:19:09', '', 'P051565352L', '', '', 'KCB', '', '25955825', '8600.00', 'primary', 'Strawberry Events', 7),
('EMP-0KA40ZI', 'Philip Keter', 'Male', '0000-00-00', 'transportations', 'driver', '', '', '2016-04-20 09:03:04', '', 'P051565352L', '', '', 'KCB', '', '20275778', '9600.00', 'primary', 'Strawberry Events', 8),
('EMP-962S45O', 'Lokiru Joshuoa', 'Male', '0000-00-00', 'events', '', '', '', '2016-04-20 09:06:58', '', 'P051565352L', '', '', 'KCB', '', '29254563', '8600.00', 'primary', 'Strawberry Events', 9),
('EMP-L683UQ0', 'Momanyi Wilfred', 'Male', '0000-00-00', 'events', '', '', '', '2016-04-20 09:08:55', '', 'P051565352L', '', '', 'KCB', '', '29471494', '8600.00', 'primary', 'Strawberry Events', 10),
('EMP-W1D7BK9', 'Muhia Dominic', 'Male', '0000-00-00', 'events', '', '', '', '2016-04-20 09:10:09', '', 'P051565352L', '', '', 'KCB', '', '30958649', '7600.00', 'primary', 'Strawberry Events', 11),
('EMP-D21FOA5', 'Okoth Raphael', 'Male', '0000-00-00', '', '', '', '', '2016-04-20 09:12:50', '', 'P051565352L', '', '', 'KCB', '', '10320954', '8100.00', '', '', 12),
('EMP-14QG3Q1', 'Boit Naomy', 'Female', '0000-00-00', 'catering', '', '', '', '2016-04-20 09:24:52', '', 'P051565352L', '', '', 'KCB', '', '22721046', '7600.00', 'primary', 'Strawberry Events', 13),
('EMP-57GN5RX', 'Yabei Joseph', 'Male', '0000-00-00', 'transportations', 'driver', '', '', '2016-04-20 09:26:10', '', 'P051565352L', '', '', 'KCB', '', '20268194', '9600.00', 'primary', 'Strawberry Events', 14),
('EMP-6M5D4K6', 'Nyamboke Elizabeth', 'Female', '0000-00-00', 'catering', 'cook', '', '', '2016-04-20 09:28:23', '', 'P051565352L', '', '', 'KCB', '', '26958826', '7600.00', 'primary', 'Strawberry Events', 15),
('EMP-49O93Z1', 'Libale Nelson', 'Male', '0000-00-00', 'events', '', '', '', '2016-04-20 09:30:42', '', 'P051565352L', '', '', 'KCB', '', '23804379', '10100.00', 'primary', 'Strawberry Events', 16),
('EMP-P83I14F', 'Albela George', 'Male', '0000-00-00', 'events', '', '', '', '2016-04-20 09:32:48', '', 'P051565352L', '', '', 'KCB', '', '33156595', '8600.00', 'primary', 'Strawberry Events', 17),
('EMP-AD81J7G', 'Kogo Julius', 'Male', '0000-00-00', 'transportations', 'driver', '', '', '2016-04-20 09:56:40', '', 'P051565352L', '', '', 'KCB', '', '13017247', '9600.00', 'primary', 'Strawberry Events', 18),
('EMP-D40B5DQ', 'Musungu Simon', 'Male', '0000-00-00', '', '', '', '', '2016-04-20 09:58:49', '', 'P051565352L', '', '', 'KCB', '', '28786769', '8600.00', '', '', 19),
('EMP-HFOPB5F', 'Cheruiyot Rael', 'Female', '0000-00-00', '', '', '', '', '2016-04-20 10:02:11', '', 'P051565352L', '', '', 'KCB', '', '24205554', '15800.00', '', '', 20),
('EMP-99O7DIH', 'Kosgei Josphat', 'Male', '0000-00-00', 'transportations', 'driver', '', '', '2016-04-20 10:04:56', '', 'P051565352L', '', '', 'Select Bank', '', '', '8600.00', 'primary', 'Strawberry Events', 21),
('EMP-S9186X7', 'Edward', 'Male', '0000-00-00', 'events', '', '', '', '2016-04-20 10:05:53', '', 'P051565352L', '', '', 'KCB', '', '', '7600.00', 'primary', 'Strawberry Events', 22),
('EMP-6P9B34R', 'Meshack', 'Male', '0000-00-00', '', '', '', '', '2016-04-20 10:06:45', '', 'P051565352L', '', '', 'KCB', '', '', '35000.00', 'primary', '', 23),
('EMP-2L1JX1E', 'Hillary', 'Male', '0000-00-00', 'events', '', '', '', '2016-04-20 10:07:47', '', 'P051565352L', '', '', 'KCB', '', '', '7600.00', 'primary', 'Strawberry Events', 24),
('EMP-734DB27', 'Karama Ken', 'Male', '0000-00-00', 'events', '', '', '', '2016-04-20 10:08:40', '', 'P051565352L', '', '', 'KCB', '', '', '7600.00', 'primary', 'Strawberry Events', 25),
('EMP-9XCC2EI', '', '', '0000-00-00', '', '', '', '', '2016-06-04 09:43:35', '', 'P051565352L', '', '', 'Select Bank', '', '', '0.00', 'primary', 'Strawberry Events', 26);

-- --------------------------------------------------------

--
-- Table structure for table `salary`
--

CREATE TABLE IF NOT EXISTS `salary` (
  `salary_id` int(50) NOT NULL AUTO_INCREMENT,
  `staff_id` varchar(50) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `department` varchar(50) NOT NULL,
  `position` varchar(50) NOT NULL,
  `years` varchar(50) NOT NULL,
  `grade` varchar(50) NOT NULL,
  `basic` decimal(10,2) NOT NULL,
  `meal` decimal(10,2) NOT NULL,
  `housing` decimal(10,2) NOT NULL,
  `transport` decimal(10,2) NOT NULL,
  `entertainment` varchar(50) NOT NULL,
  `long_service` decimal(10,2) NOT NULL,
  `tax` decimal(10,2) NOT NULL,
  `totall` decimal(10,2) NOT NULL,
  `date_s` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `nhif` decimal(10,2) NOT NULL DEFAULT '0.00',
  `nssf` decimal(10,2) NOT NULL DEFAULT '0.00',
  `advance` decimal(10,2) NOT NULL,
  `dnw` decimal(10,2) NOT NULL DEFAULT '0.00',
  `loans` decimal(10,2) NOT NULL DEFAULT '0.00',
  `emp_pin` varchar(40) NOT NULL,
  `personal_relief` varchar(40) NOT NULL,
  `payee` decimal(10,2) NOT NULL,
  `bonus` decimal(10,2) NOT NULL,
  `otherincome` decimal(10,2) NOT NULL,
  `pension` decimal(10,2) NOT NULL,
  `taxincome` decimal(10,2) NOT NULL,
  `nettax` decimal(10,2) NOT NULL,
  `totaldeduc` decimal(10,2) NOT NULL,
  `totalincome` decimal(10,2) NOT NULL,
  `empl_pin` varchar(40) NOT NULL,
  `meals` decimal(10,2) NOT NULL,
  `accno` varchar(40) NOT NULL,
  `bank` varchar(40) NOT NULL,
  `others` decimal(10,2) NOT NULL,
  `period` varchar(40) NOT NULL,
  `nhno` varchar(40) NOT NULL,
  `nssfno` varchar(40) NOT NULL,
  `idno` varchar(40) NOT NULL,
  `receiptno` varchar(40) NOT NULL,
  `id` varchar(40) NOT NULL,
  PRIMARY KEY (`salary_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `salary`
--

INSERT INTO `salary` (`salary_id`, `staff_id`, `fname`, `department`, `position`, `years`, `grade`, `basic`, `meal`, `housing`, `transport`, `entertainment`, `long_service`, `tax`, `totall`, `date_s`, `nhif`, `nssf`, `advance`, `dnw`, `loans`, `emp_pin`, `personal_relief`, `payee`, `bonus`, `otherincome`, `pension`, `taxincome`, `nettax`, `totaldeduc`, `totalincome`, `empl_pin`, `meals`, `accno`, `bank`, `others`, `period`, `nhno`, `nssfno`, `idno`, `receiptno`, `id`) VALUES
(1, 'EMP-2L1JX1E', 'Hillary', 'events', '', '', '', '7600.00', '0.00', '0.00', '0.00', '0', '0.00', '0.00', '7100.00', '2016-06-04 09:44:36', '300.00', '200.00', '0.00', '0.00', '0.00', '', '0', '0.00', '0.00', '0.00', '200.00', '7400.00', '0.00', '500.00', '7600.00', 'P051565352L', '0.00', '', 'KCB', '0.00', 'Jun,2016', '', '', '', 'EMP-2L1JX1E', '24'),
(2, 'EMP-6P9B34R', 'Meshack', '', '', '', '', '35000.00', '0.00', '0.00', '0.00', '0', '0.00', '0.00', '29274.25', '2016-06-04 09:46:31', '950.00', '200.00', '0.00', '0.00', '0.00', '', '1162.00', '5737.75', '0.00', '0.00', '200.00', '34800.00', '4575.75', '5725.75', '35000.00', 'P051565352L', '0.00', '', 'KCB', '0.00', 'Jun,2016', '', '', '', 'EMP-6P9B34R', '23');

-- --------------------------------------------------------

--
-- Table structure for table `staff_inbox`
--

CREATE TABLE IF NOT EXISTS `staff_inbox` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` varchar(50) NOT NULL,
  `sender` varchar(100) NOT NULL,
  `receiver` varchar(100) NOT NULL,
  `msg_subject` text NOT NULL,
  `msg_msg` text NOT NULL,
  `received_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `staff_outbox`
--

CREATE TABLE IF NOT EXISTS `staff_outbox` (
  `so_id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(50) NOT NULL,
  `sender` varchar(100) NOT NULL,
  `receiver` varchar(100) NOT NULL,
  `msg_subject` text NOT NULL,
  `msg_msg` text NOT NULL,
  `date_sent` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`so_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(2, 'admin', 'admin'),
(3, 'too', 'bethwel1');

-- --------------------------------------------------------

--
-- Table structure for table `variables`
--

CREATE TABLE IF NOT EXISTS `variables` (
  `housing` varchar(40) NOT NULL,
  `transport` varchar(40) NOT NULL,
  `tax` float NOT NULL,
  `entertainment` float NOT NULL,
  `long_service` float NOT NULL,
  `nssf` decimal(10,2) NOT NULL,
  `personal_relief` decimal(10,2) NOT NULL,
  `pension` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `variables`
--

INSERT INTO `variables` (`housing`, `transport`, `tax`, `entertainment`, `long_service`, `nssf`, `personal_relief`, `pension`) VALUES
('P051565352L', 'STRAWBERRY EVENTS LIMITED', 0.3, 0, 0, '200.00', '1162.00', '200.00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
