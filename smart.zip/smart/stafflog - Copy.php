<?php
{
		echo'<h1>Product Stickers</h1>';
				 include('connection.php');
				    $sel=mysql_query("SELECT * FROM  codes");
					
					$rowscheck=mysql_num_rows($sel);
		 if($rowscheck < 1){
		 echo 'Sticker not available. click <a href="home.php?action=pdetails">here</a> add New Products';
		 
		 }else{
		 
		 
			?>					<script language="javascript">
function caaictpms()
{ 
  var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
      disp_setting+="scrollbars=yes"; 
  var content_vlue = document.getElementById("print_content").innerHTML; 
  
  var docprint=window.open("","",disp_setting); 
   docprint.document.open(); 
   docprint.document.write('<html><head><title>PRODUCT SECURITY AND VALIDATION SYSTEM </title>'); 
      docprint.document.write('<p align="center"> <FONT size="+3"><img src="images/logo.png" >PRODUCT SECURITY AND VALIDATION SYSTEM</FONT></p><P  align="center">PRODUCT SECURITY AND VALIDATION SYSTEM</P><BR><P  align="center"> Status of Projects</P>');
   docprint.document.write('</head><body onLoad="self.print()" style="width:800px; font-size:10px; margin-left:40px; -cell-padding:none;font: 12px/17px arial, sans-serif;color: rgb(50, 50, 50);">');
             
   docprint.document.write(content_vlue);          
   docprint.document.write('</body></html>'); 
   docprint.document.close(); 
   docprint.focus(); 
}
</script>
<div  id="print_content">
                           <p class="pprint"> <a href="javascript:caaictpms()" ><img src="images/Print.png" width="30" height="30" /></a></p><br/>
		 
		 <?php
		
			$flag=0;
			while($fetch=mysql_fetch_array($sel)){
			if($flag%2==0)
			echo '<tr bgcolor=#E5E5E5>';
			
	else 
		
ECHO "<br>";
  ECHO "<br>";
   ECHO "<SMALL><small>";
	   ECHO "<table border='1'>";
	   ECHO "<tr>";
	   ECHO "<td>";
	   
      echo 
	  
         "PSSN:<B> {$fetch['psno']}</B> <br> ".
         "PSPN: <B>{$fetch['pins']} </B><br> ".
		 "HASH :<B> {$fetch['hash']} </B> ".
         "<br>";
		  
		 ECHO "</td>";
		 ECHO "</tr>";
		 ECHO "</table>";ECHO "</SMALL></small>";








			$flag++; 
			}
			echo '<br>';
			echo '</table>';
		
	
	
	
	
echo '<tr bgcolor=white>';
echo '<td>'.$fetch['psno'].'</td><td>'.$fetch['pins'].'</td><td>'.$fetch['hash'].'</td></tr>';
			  
			$flag=$flag+1;
			}
			echo '</table>';
			
						
				}?>
				</div>
				
	

	
	
	
	
	
	
	
	