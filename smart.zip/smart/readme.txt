Payroll automation and personnel management was my web development class project. With this application, you can register employee into database, update their information, send them instant message, delete employee and finally calculate the payroll of employees using the following variables:
15% of basic salary as housing allowance, 8% of basic salary as transport allowance, 9% of salary as tax deductions, for staff who has spent more than 15years gets 1.75% of salary as long service allowance and also, staff who is above grade 7 and above gets 2% of salary as entertainment allowance and finally everybody gets 500 as meal subsidy allowance.
It also includes staff section where employees can see their profile, gets a breakdown of salary payments and also send and receive messages from other staff.

ADMIN LOGIN
Admin username: windscreen
Admin password: adeniji


FOR STAFF LOGIN
Staff ID = 2
Username = Senami
Password = 12345678
